import 'package:flutter/material.dart';
import 'package:open_iptv/shared/utils/display_name.dart';
import 'package:open_iptv/shared/widgets/tv_focusable.dart';

/// Standardized category/genre row: icon, label, item count, optional lock
/// badge, and a trailing chevron. Used for Live TV categories and Movies/
/// Series genre lists, which previously reimplemented this identically in
/// three separate files.
class CategoryTile extends StatelessWidget {
  const CategoryTile({
    super.key,
    required this.label,
    required this.count,
    required this.icon,
    required this.onTap,
    this.isLocked = false,
    this.onLongPress,
    this.autofocus = false,
  });

  final String label;
  final int count;
  final IconData icon;
  final VoidCallback onTap;
  final bool isLocked;
  final VoidCallback? onLongPress;
  final bool autofocus;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return TvFocusable(
      onTap: onTap,
      onLongPress: onLongPress,
      autofocus: autofocus,
      ensureVisibleOnFocus: true,
      child: ListTile(
        leading: Icon(icon, color: theme.colorScheme.primary),
        title: Text(context.displayName(label)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (isLocked)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: Icon(Icons.lock_outline,
                    size: 16, color: theme.colorScheme.onSurfaceVariant),
              ),
            Text(
              count.toString(),
              style: theme.textTheme.bodySmall!.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right),
          ],
        ),
        enableFeedback: false,
      ),
    );
  }
}
