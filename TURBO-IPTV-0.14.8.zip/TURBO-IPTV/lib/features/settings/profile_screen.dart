import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:open_iptv/core/models/profile.dart';
import 'package:open_iptv/core/services/admin_biometric.dart';
import 'package:open_iptv/core/services/profile_service.dart';
import 'package:open_iptv/core/storage/preferences.dart';
import 'package:open_iptv/shared/theme/app_theme.dart';
import 'package:open_iptv/shared/widgets/info_tooltip.dart';
import 'package:open_iptv/shared/widgets/loading_view.dart';
import 'package:open_iptv/shared/widgets/parental_pin_dialog.dart';
import 'package:open_iptv/shared/widgets/pin_field.dart';
import 'package:open_iptv/shared/widgets/profile_avatar.dart';
import 'package:open_iptv/shared/widgets/settings_group.dart';
import 'package:open_iptv/shared/widgets/tv_focusable.dart';
import 'package:open_iptv/ui/platform_helper.dart';

/// Profile overview screen — shows the active profile and lets the user
/// manage settings, PIN, kids mode, and other profiles.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeAsync = ref.watch(activeProfileProvider);
    final allAsync = ref.watch(allProfilesProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: activeAsync.when(
        loading: () => const LoadingView(),
        error: (_, __) => const Center(child: Text("Couldn't load profile.")),
        data: (profile) {
          if (profile == null) {
            return const Center(child: Text('No active profile.'));
          }
          final String kidsSubtitle;
          if (profile.isAdmin) {
            kidsSubtitle = "Admin accounts can't be marked as kid accounts";
          } else if (profile.isKidsProfile) {
            kidsSubtitle = 'Adult content will be hidden';
          } else {
            kidsSubtitle = 'All content is visible';
          }
          void showPinDialog() => _showPinDialog(
                context,
                ref,
                profile,
                blockPinRemoval:
                    profile.isAdmin && (allAsync.valueOrNull?.length ?? 1) > 1,
              );
          return ListView(
            children: [
              // ── Hero ──────────────────────────────────────────────
              _ProfileHero(
                profile: profile,
                onEdit: () => _showEditDialog(context, ref, profile),
              ),
              // ── Account ───────────────────────────────────────────
              SettingsGroup(title: 'Account', children: [
                InfoTooltipScope(
                  controller: InfoTooltipController(),
                  child: InfoTooltip(
                    id: 'kids_profile',
                    title: 'Kids Profile',
                    body: 'When turned on, this profile is marked as a Kids '
                        'profile and adult content is automatically hidden '
                        'from Live, Movies, and Series. Requires Parental '
                        'Protection to be enabled.',
                    child: TvActivatable(
                      autofocus: true,
                      onTap: profile.isAdmin
                          ? null
                          : () => _setKidsProfile(
                              context, ref, profile, !profile.isKidsProfile),
                      builder: (_) => SwitchListTile(
                        secondary:
                            const IconBadge(icon: Icons.child_care_outlined),
                        title: const Text('Kids Profile'),
                        subtitle: Text(kidsSubtitle,
                            style: theme.textTheme.bodySmall),
                        value: profile.isKidsProfile,
                        onChanged: profile.isAdmin
                            ? null
                            : (val) =>
                                _setKidsProfile(context, ref, profile, val),
                      ),
                    ),
                  ),
                ),
              ]),

              // ── Security ──────────────────────────────────────────
              if (!profile.isKidsProfile)
                SettingsGroup(title: 'Security', children: [
                  TvActivatable(
                    autofocus: profile.isAdmin,
                    onTap: showPinDialog,
                    builder: (onTap) => ListTile(
                      leading: IconBadge(
                          icon: profile.hasPin
                              ? Icons.lock_outline
                              : Icons.lock_open_outlined),
                      title: const Text('PIN Lock'),
                      subtitle: Text(
                        profile.hasPin
                            ? 'PIN is set — tap to change or remove'
                            : 'No PIN — tap to set one',
                        style: theme.textTheme.bodySmall,
                      ),
                      trailing: profile.hasPin
                          ? Icon(Icons.check_circle,
                              color: theme.colorScheme.primary, size: 20)
                          : null,
                      onTap: onTap,
                    ),
                  ),
                  // Fingerprint / face for admin PIN prompts (#47): the
                  // admin's own profile, on phones with strong biometrics.
                  if (profile.isAdmin) _AdminBiometricTile(profile: profile),
                ]),

              // ── All Profiles (admin only) ─────────────────────────
              if (profile.isAdmin)
                SettingsGroup(title: 'All Profiles', children: [
                  allAsync.when(
                    loading: () => const SizedBox.shrink(),
                    error: (_, __) => const SizedBox.shrink(),
                    data: (all) => Column(
                      children: [
                        ...all.map((p) => TvRevealOnFocus(
                              child: _ProfileTile(
                                profile: p,
                                isActive: p.id == profile.id,
                                onEdit: () => _showEditDialog(context, ref, p),
                                onDelete: all.length > 1
                                    ? () => _confirmDelete(context, ref, p)
                                    : null,
                              ),
                            )),
                        TvActivatable(
                          onTap: () => _showCreateDialog(context, ref),
                          builder: (onTap) => ListTile(
                            leading: const IconBadge(icon: Icons.add),
                            title: const Text('Add Profile'),
                            onTap: onTap,
                          ),
                        ),
                      ],
                    ),
                  ),
                ]),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }

  /// Turning Kids Profile on requires Parental Protection (offering to enable
  /// it if it isn't yet); turning it off requires an admin PIN.
  Future<void> _setKidsProfile(
      BuildContext context, WidgetRef ref, Profile profile, bool val) async {
    if (val) {
      final prefs = await ref.read(appPreferencesProvider.future);
      if (!context.mounted) return;
      if (!prefs.parentalProtectionEnabled) {
        final enable = await _showParentalProtectionRequiredDialog(context);
        if (!enable) return;
        await prefs.setParentalProtectionEnabled(true);
      }
    } else {
      if (!await promptAdminPin(
          context, ref, 'Enter admin PIN to disable Kids Profile')) {
        return;
      }
    }
    await ref.read(profileServiceProvider).updateProfile(
          profile.copyWith(isKidsProfile: val, updatedAt: DateTime.now()),
        );
    ref.invalidate(activeProfileProvider);
  }

  Future<void> _showEditDialog(
      BuildContext context, WidgetRef ref, Profile profile) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => _EditProfileDialog(profile: profile, ref: ref),
    );
    ref.invalidate(activeProfileProvider);
    ref.invalidate(allProfilesProvider);
  }

  Future<void> _showCreateDialog(BuildContext context, WidgetRef ref) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => _CreateProfileDialog(ref: ref),
    );
    ref.invalidate(allProfilesProvider);
  }

  Future<void> _showPinDialog(
    BuildContext context,
    WidgetRef ref,
    Profile profile, {
    bool blockPinRemoval = false,
  }) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => _PinManagementDialog(
        profile: profile,
        ref: ref,
        blockPinRemoval: blockPinRemoval,
      ),
    );
    ref.invalidate(activeProfileProvider);
    ref.invalidate(allProfilesProvider);
  }

  Future<void> _confirmDelete(
      BuildContext context, WidgetRef ref, Profile profile) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Profile?'),
        content: Text(
          'Deleting "${profile.name}" will remove all its favourites and '
          'settings. Your sources and channels are not affected.',
        ),
        actions: [
          TvActivatable(
            autofocus: true,
            onTap: () => Navigator.of(ctx).pop(false),
            builder: (onTap) =>
                TextButton(onPressed: onTap, child: const Text('Annuler')),
          ),
          TvActivatable(
            onTap: () => Navigator.of(ctx).pop(true),
            builder: (onTap) => FilledButton(
              style: AppTheme.destructiveButtonStyle(ctx),
              onPressed: onTap,
              child: const Text('Supprimer'),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await ref.read(profileServiceProvider).deleteProfile(profile.id);
      ref.invalidate(allProfilesProvider);
      ref.invalidate(activeProfileProvider);
    } on StateError catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
      }
    }
  }
}

/// Shows the "Parental Protection Required" prompt used whenever the user
/// tries to mark a profile as a Kids profile while Parental Protection is
/// still disabled. Returns whether the user chose to enable it.
Future<bool> _showParentalProtectionRequiredDialog(BuildContext context) async {
  final enable = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Parental Protection Required'),
      content: const Text(
          'Kid profiles require Parental Protection to be turned on, so '
          'adult content can be hidden automatically. Enable it now?'),
      actions: [
        TvActivatable(
          autofocus: true,
          onTap: () => Navigator.pop(context, false),
          builder: (onTap) =>
              TextButton(onPressed: onTap, child: const Text('Annuler')),
        ),
        TvActivatable(
          onTap: () => Navigator.pop(context, true),
          builder: (onTap) => FilledButton(
              onPressed: onTap, child: const Text('Enable Protection')),
        ),
      ],
    ),
  );
  return enable == true;
}

// ---------------------------------------------------------------------------
// Profile hero header
// ---------------------------------------------------------------------------

class _ProfileHero extends StatelessWidget {
  const _ProfileHero({required this.profile, required this.onEdit});

  final Profile profile;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 28),
      child: Column(
        children: [
          Stack(
            alignment: Alignment.bottomRight,
            children: [
              ProfileAvatar(
                emoji: profile.avatarEmoji,
                name: profile.name,
                size: 104,
              ),
              TvFocusable(
                onTap: onEdit,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary,
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: theme.scaffoldBackgroundColor, width: 2),
                  ),
                  child: Icon(Icons.edit_rounded,
                      size: 16, color: theme.colorScheme.onPrimary),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(profile.name,
              style: theme.textTheme.headlineSmall!
                  .copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text('Active',
                    style: theme.textTheme.bodySmall!
                        .copyWith(color: theme.colorScheme.primary)),
              ),
              if (profile.isKidsProfile) ...[
                const SizedBox(width: 6),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text('Kids',
                      style: theme.textTheme.bodySmall!
                          .copyWith(color: Colors.green)),
                ),
              ],
              if (profile.hasPin) ...[
                const SizedBox(width: 6),
                Icon(Icons.lock,
                    size: 14, color: theme.colorScheme.onSurfaceVariant),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Profile list tile (for All Profiles section)
// ---------------------------------------------------------------------------

class _ProfileTile extends StatelessWidget {
  const _ProfileTile({
    required this.profile,
    required this.isActive,
    required this.onEdit,
    required this.onDelete,
  });

  final Profile profile;
  final bool isActive;
  final VoidCallback onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final menuKey = GlobalKey<PopupMenuButtonState<_Action>>();
    return ListTile(
      leading: Stack(
        children: [
          ProfileAvatar(emoji: profile.avatarEmoji, name: profile.name),
          if (isActive)
            Positioned(
              right: 0,
              bottom: 0,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary,
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: theme.scaffoldBackgroundColor, width: 1.5),
                ),
              ),
            ),
        ],
      ),
      title: Text(profile.name),
      subtitle: Row(
        children: [
          if (isActive)
            Text('Active',
                style: theme.textTheme.bodySmall!
                    .copyWith(color: theme.colorScheme.primary)),
          if (isActive && profile.isKidsProfile) const Text(' · '),
          if (profile.isKidsProfile)
            Text('Kids', style: theme.textTheme.bodySmall),
          if ((isActive || profile.isKidsProfile) && profile.hasPin)
            const Text(' · '),
          if (profile.hasPin)
            Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.lock_outline,
                  size: 12, color: theme.colorScheme.onSurfaceVariant),
              const SizedBox(width: 2),
              Text('PIN', style: theme.textTheme.bodySmall),
            ]),
        ],
      ),
      trailing: TvFocusable(
        wrapsGesture: false,
        onTap: () => menuKey.currentState?.showButtonMenu(),
        child: TvMenuTheme(
          child: PopupMenuButton<_Action>(
            key: menuKey,
            onSelected: (a) {
              if (a == _Action.edit) onEdit();
              if (a == _Action.delete) onDelete?.call();
            },
            itemBuilder: (_) => [
              const PopupMenuItem(
                  value: _Action.edit,
                  child: TvInitialFocus(child: Text('Modifier'))),
              if (onDelete != null) ...[
                const PopupMenuDivider(),
                const PopupMenuItem(
                    value: _Action.delete, child: Text('Supprimer')),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

enum _Action { edit, delete }

// ---------------------------------------------------------------------------
// Edit profile dialog
// ---------------------------------------------------------------------------

class _EditProfileDialog extends StatefulWidget {
  const _EditProfileDialog({required this.profile, required this.ref});
  final Profile profile;
  final WidgetRef ref;

  @override
  State<_EditProfileDialog> createState() => _EditProfileDialogState();
}

class _EditProfileDialogState extends State<_EditProfileDialog> {
  late final TextEditingController _name;
  late String _emoji;
  String? _error;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.profile.name);
    _emoji = widget.profile.avatarEmoji;
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Please enter a name.');
      return;
    }
    try {
      await widget.ref.read(profileServiceProvider).updateProfile(
            widget.profile.copyWith(name: name, avatarEmoji: _emoji),
          );
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      setState(() => _error = "Couldn't save changes.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Edit Profile'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Name'),
            const SizedBox(height: 8),
            TvTextFieldGate(
              autofocus: true,
              builder: (context, fieldNode) => TextField(
                focusNode: fieldNode,
              controller: _name,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _save(),
            )
            ),
            const SizedBox(height: 16),
            const Text('Avatar'),
            const SizedBox(height: 8),
            _EmojiPicker(
              selected: _emoji,
              onSelected: (e) => setState(() => _emoji = e),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                      fontSize: 13)),
            ],
          ],
        ),
      ),
      actions: [
        TvActivatable(
          onTap: () => Navigator.of(context).pop(),
          builder: (onTap) =>
              TextButton(onPressed: onTap, child: const Text('Annuler')),
        ),
        TvActivatable(
          // A plain autofocus TextField above would trap D-pad focus there
          // permanently (Flutter's EditableText consumes vertical arrow
          // keys), so this button gets the default focus instead — the
          // field is still one press up if the name needs editing.
          autofocus: true,
          onTap: _save,
          builder: (onTap) =>
              FilledButton(onPressed: onTap, child: const Text('Enregistrer')),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Create profile dialog
// ---------------------------------------------------------------------------

class _CreateProfileDialog extends StatefulWidget {
  const _CreateProfileDialog({required this.ref});
  final WidgetRef ref;

  @override
  State<_CreateProfileDialog> createState() => _CreateProfileDialogState();
}

class _CreateProfileDialogState extends State<_CreateProfileDialog> {
  final _name = TextEditingController();
  String _emoji = Profile.avatarOptions.first;
  bool _isKidAccount = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _onKidToggle(bool val) async {
    if (val) {
      final prefs = await widget.ref.read(appPreferencesProvider.future);
      if (!mounted) return;
      if (!prefs.parentalProtectionEnabled) {
        final enable = await _showParentalProtectionRequiredDialog(context);
        if (!enable) return;
        await prefs.setParentalProtectionEnabled(true);
      }
    }
    if (mounted) setState(() => _isKidAccount = val);
  }

  Future<void> _create() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Please enter a name.');
      return;
    }
    try {
      await widget.ref.read(profileServiceProvider).createProfile(
            name: name,
            avatarEmoji: _emoji,
            isKidsProfile: _isKidAccount,
          );
      if (mounted) Navigator.of(context).pop();
    } on StateError catch (e) {
      setState(() => _error = e.message);
    } catch (_) {
      setState(() => _error = "Couldn't create profile.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('New Profile'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Name'),
            const SizedBox(height: 8),
            TvTextFieldGate(
              autofocus: true,
              builder: (context, fieldNode) => TextField(
                focusNode: fieldNode,
              controller: _name,
              decoration:
                  const InputDecoration(hintText: 'e.g. Kids, Living Room'),
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _create(),
            )
            ),
            const SizedBox(height: 16),
            const Text('Avatar'),
            const SizedBox(height: 8),
            _EmojiPicker(
              selected: _emoji,
              onSelected: (e) => setState(() => _emoji = e),
            ),
            const SizedBox(height: 8),
            TvActivatable(
              onTap: () => _onKidToggle(!_isKidAccount),
              builder: (_) => SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.child_care_outlined),
                title: const Text('Is Kid Account'),
                subtitle: Text(
                  _isKidAccount
                      ? 'Adult content will be hidden'
                      : 'All content is visible',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                value: _isKidAccount,
                onChanged: _onKidToggle,
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                      fontSize: 13)),
            ],
          ],
        ),
      ),
      actions: [
        TvActivatable(
          onTap: () => Navigator.of(context).pop(),
          builder: (onTap) =>
              TextButton(onPressed: onTap, child: const Text('Annuler')),
        ),
        TvActivatable(
          // A plain autofocus TextField above would trap D-pad focus there
          // permanently (Flutter's EditableText consumes vertical arrow
          // keys), so this button gets the default focus instead — the
          // field, avatar picker, and Kid Account toggle are still one or
          // more presses up if they need editing.
          autofocus: true,
          onTap: _create,
          builder: (onTap) =>
              FilledButton(onPressed: onTap, child: const Text('Create')),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// PIN management dialog
// ---------------------------------------------------------------------------

class _PinManagementDialog extends StatefulWidget {
  const _PinManagementDialog({
    required this.profile,
    required this.ref,
    this.blockPinRemoval = false,
  });
  final Profile profile;
  final WidgetRef ref;
  final bool blockPinRemoval;

  @override
  State<_PinManagementDialog> createState() => _PinManagementDialogState();
}

class _PinManagementDialogState extends State<_PinManagementDialog> {
  final _current = TextEditingController();
  final _newPin = TextEditingController();
  final _confirm = TextEditingController();
  String? _error;
  bool _obscureCurrent = true;
  bool _obscureNew = true;
  bool _obscureConfirm = true;

  @override
  void dispose() {
    _current.dispose();
    _newPin.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final newPin = _newPin.text.trim();
    if (newPin != _confirm.text.trim()) {
      setState(() => _error = "PINs don't match.");
      return;
    }
    if (newPin.length < 4) {
      setState(() => _error = 'PIN must be at least 4 digits.');
      return;
    }
    if (widget.profile.hasPin) {
      final ok = widget.ref
          .read(profileServiceProvider)
          .verifyPin(widget.profile, _current.text.trim());
      if (!ok) {
        setState(() => _error = 'Current PIN is incorrect.');
        return;
      }
    }
    await widget.ref
        .read(profileServiceProvider)
        .setPin(widget.profile.id, newPin);
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _remove() async {
    try {
      await widget.ref.read(profileServiceProvider).clearPin(
            widget.profile.id,
            currentPin: _current.text.trim(),
          );
      if (mounted) Navigator.of(context).pop();
    } on ArgumentError {
      setState(() => _error = 'Current PIN is incorrect.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.profile.hasPin ? 'Change PIN' : 'Set PIN'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.profile.hasPin) ...[
              const Text('Current PIN'),
              const SizedBox(height: 6),
              TvTextFieldGate(
                autofocus: true,
                builder: (context, fieldNode) => TextField(
                  focusNode: fieldNode,
                controller: _current,
                keyboardType: TextInputType.number,
                obscureText: _obscureCurrent,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                maxLength: 8,
                textInputAction: TextInputAction.next,
                decoration: InputDecoration(
                  hintText: 'Current PIN',
                  // TV: the "0/8" sat inside the focus outline.
                  counterText: PlatformHelper.isTV(context) ? '' : null,
                  suffixIcon: _obscureToggle(
                    obscured: _obscureCurrent,
                    onToggle: () =>
                        setState(() => _obscureCurrent = !_obscureCurrent),
                  ),
                ),
              )
              ),
              const SizedBox(height: 4),
            ],
            const Text('New PIN'),
            const SizedBox(height: 6),
            TvTextFieldGate(
              autofocus: !widget.profile.hasPin,
              builder: (context, fieldNode) => TextField(
                focusNode: fieldNode,
              controller: _newPin,
              keyboardType: TextInputType.number,
              obscureText: _obscureNew,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              maxLength: 8,
              autofocus:
                  !widget.profile.hasPin && !PlatformHelper.isTV(context),
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                hintText: '4–8 digits',
                counterText: PlatformHelper.isTV(context) ? '' : null,
                suffixIcon: _obscureToggle(
                  obscured: _obscureNew,
                  onToggle: () => setState(() => _obscureNew = !_obscureNew),
                ),
              ),
            )
            ),
            const SizedBox(height: 4),
            const Text('Confirm PIN'),
            const SizedBox(height: 6),
            TvTextFieldGate(
              builder: (context, fieldNode) => TextField(
                focusNode: fieldNode,
              controller: _confirm,
              keyboardType: TextInputType.number,
              obscureText: _obscureConfirm,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              maxLength: 8,
              decoration: InputDecoration(
                hintText: 'Repeat new PIN',
                counterText: PlatformHelper.isTV(context) ? '' : null,
                suffixIcon: _obscureToggle(
                  obscured: _obscureConfirm,
                  onToggle: () =>
                      setState(() => _obscureConfirm = !_obscureConfirm),
                ),
              ),
              onSubmitted: (_) => _save(),
            )
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                      fontSize: 13)),
            ],
          ],
        ),
      ),
      actions: [
        TvActivatable(
          onTap: () => Navigator.of(context).pop(),
          builder: (onTap) =>
              TextButton(onPressed: onTap, child: const Text('Annuler')),
        ),
        if (widget.profile.hasPin && !widget.blockPinRemoval)
          TvActivatable(
            onTap: _remove,
            builder: (onTap) => FilledButton(
              style: AppTheme.destructiveButtonStyle(context),
              onPressed: onTap,
              child: const Text('Remove PIN'),
            ),
          ),
        TvActivatable(
          onTap: _save,
          builder: (onTap) =>
              FilledButton(onPressed: onTap, child: const Text('Enregistrer')),
        ),
      ],
    );
  }

  /// The show/hide eye inside a PIN field. A plain IconButton here can't be
  /// reached by the D-pad, so the bare icon gets its own focus target.
  Widget _obscureToggle({
    required bool obscured,
    required VoidCallback onToggle,
  }) {
    return TvFocusable(
      onTap: onToggle,
      child: Icon(obscured ? Icons.visibility : Icons.visibility_off),
    );
  }
}

// ---------------------------------------------------------------------------
// Emoji picker
// ---------------------------------------------------------------------------

class _EmojiPicker extends StatelessWidget {
  const _EmojiPicker({required this.selected, required this.onSelected});

  final String selected;
  final void Function(String) onSelected;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: Profile.avatarOptions.map((emoji) {
        final isSelected = emoji == selected;
        return TvFocusable(
          onTap: () => onSelected(emoji),
          borderRadius: BorderRadius.circular(8),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isSelected
                  ? Theme.of(context).colorScheme.primary.withValues(alpha: 0.2)
                  : Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isSelected
                    ? Theme.of(context).colorScheme.primary
                    : Colors.transparent,
                width: 2,
              ),
            ),
            child: Center(
              child: Text(emoji, style: const TextStyle(fontSize: 20)),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// "Unlock with Fingerprint or Face" under Security (#47). Hidden where the
/// device can't do strong biometrics (and on TVs).
class _AdminBiometricTile extends ConsumerStatefulWidget {
  const _AdminBiometricTile({required this.profile});

  final Profile profile;

  @override
  ConsumerState<_AdminBiometricTile> createState() =>
      _AdminBiometricTileState();
}

class _AdminBiometricTileState extends ConsumerState<_AdminBiometricTile> {
  void _say(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  /// Turning it on takes the admin PIN — never a scan — and then a scan to
  /// set up the device key. Turning it off needs nothing.
  Future<void> _set(AppPreferences prefs, bool on) async {
    final biometric = ref.read(adminBiometricProvider);
    if (!on) {
      await biometric.disable();
      await prefs.setAdminBiometricUnlock(false);
      if (mounted) setState(() {});
      return;
    }
    final pin = await showPinEntryDialog(
      context,
      title: 'Enter admin PIN',
      message: 'To turn on fingerprint and face unlock',
      confirmLabel: 'Continue',
    );
    if (pin == null || !mounted) return;
    if (!await ref.read(profileServiceProvider).verifyAnyAdminPin(pin)) {
      _say('Incorrect PIN');
      return;
    }
    final outcome = await biometric.enable();
    if (outcome == BiometricOutcome.success) {
      await prefs.setAdminBiometricUnlock(true);
      _say('Fingerprint and face unlock is on');
    } else if (outcome != BiometricOutcome.fallback) {
      _say("Couldn't turn on fingerprint and face unlock on this device.");
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final prefs = ref.watch(appPreferencesProvider).valueOrNull;
    final available =
        ref.watch(adminBiometricAvailableProvider).valueOrNull ?? false;
    if (prefs == null || !available) return const SizedBox.shrink();

    final hasPin = widget.profile.hasPin;
    final on = prefs.adminBiometricUnlock;
    // Turning it off is always allowed; turning it on needs the PIN.
    final canToggle = hasPin || on;
    return InfoTooltipScope(
      controller: InfoTooltipController(),
      child: InfoTooltip(
        id: 'admin_biometric',
        title: 'Unlock with Fingerprint or Face',
        body: 'Use your fingerprint or face wherever the admin PIN is '
            'asked for on this device. Anyone whose fingerprint or face is '
            'set up on this device can use it, so only turn it on if that '
            'is just you. Adding a new fingerprint or face turns it off '
            'until you turn it on again. Other profiles still use their '
            'own PINs.',
        child: TvActivatable(
          onTap: canToggle ? () => _set(prefs, !on) : null,
          builder: (_) => SwitchListTile(
            secondary: const IconBadge(icon: Icons.fingerprint),
            title: const Text('Unlock with Fingerprint or Face'),
            subtitle: Text(
              hasPin
                  ? 'Use it instead of typing the admin PIN'
                  : 'Set a PIN first',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            value: on,
            onChanged: canToggle ? (v) => _set(prefs, v) : null,
          ),
        ),
      ),
    );
  }
}
