import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:open_iptv/core/models/source.dart';
import 'package:open_iptv/core/parsers/xtream_client.dart';
import 'package:open_iptv/core/providers/theme_providers.dart';
import 'package:open_iptv/core/services/auto_refresh_service.dart';
import 'package:open_iptv/core/services/profile_service.dart';
import 'package:open_iptv/core/services/source_manager.dart';
import 'package:open_iptv/core/storage/local_playlists.dart';
import 'package:open_iptv/core/storage/preferences.dart';
import 'package:open_iptv/features/settings/car_video_addon.dart';
import 'package:open_iptv/features/settings/edit_playlist_screen.dart';
import 'package:open_iptv/features/settings/profile_picker_screen.dart';
import 'package:open_iptv/features/settings/refresh_all.dart';
import 'package:open_iptv/features/updates/update_dialog.dart';
import 'package:open_iptv/shared/theme/app_theme.dart';
import 'package:open_iptv/shared/utils/format.dart';
import 'package:open_iptv/shared/utils/friendly_error.dart';
import 'package:open_iptv/shared/utils/redact.dart';
import 'package:open_iptv/shared/widgets/info_tooltip.dart';
import 'package:open_iptv/shared/widgets/loading_view.dart';
import 'package:open_iptv/shared/widgets/profile_avatar.dart';
import 'package:open_iptv/shared/widgets/settings_group.dart';
import 'package:open_iptv/shared/widgets/tv_focusable.dart';
import 'package:open_iptv/ui/platform_helper.dart';
import 'package:package_info_plus/package_info_plus.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tooltipController = InfoTooltipController();
    final theme = Theme.of(context);

    // Derive active profile for the subtitle.
    final profile = ref.watch(activeProfileProvider).valueOrNull;
    final isAdmin = profile?.isAdmin ?? false;

    return InfoTooltipScope(
      controller: tooltipController,
      child: Scaffold(
        appBar: AppBar(title: const Text('Réglages')),
        body: ListView(
          children: [
            // --------------- PROFILES ---------------
            SettingsGroup(title: 'Compte', children: [
              InfoTooltip(
                id: 'settings_profile',
                title: 'Profil',
                body: 'TURBO IPTV gère plusieurs profils sur un même appareil. '
                    'Chaque profil a son historique, ses favoris, ses catégories masquées '
                    'et son verrouillage PIN. Touchez pour gérer les profils.',
                child: _NavTile(
                  autofocus: true,
                  leading: profile != null
                      ? ProfileAvatar(
                          emoji: profile.avatarEmoji, name: profile.name)
                      : const Icon(Icons.person_outline),
                  title: profile?.name ?? 'Profil',
                  subtitle: Text(
                    profile == null
                        ? 'Aucun profil sélectionné'
                        : '${profile.isAdmin ? 'Admin' : profile.isKidsProfile ? 'Profil enfant' : 'Profil standard'} · Gérer les profils',
                    style: theme.textTheme.bodySmall,
                  ),
                  onTap: () => context.push('/settings/profiles'),
                ),
              ),
              Consumer(builder: (context, ref, _) {
                final all = ref.watch(allProfilesProvider);
                final count = all.valueOrNull?.length ?? 0;
                if (count <= 1) return const SizedBox.shrink();
                return InfoTooltip(
                  id: 'settings_switch_profile',
                  title: 'Changer de profil',
                  body: 'Changez rapidement de profil actif sans passer par '
                      'la gestion des profils. Pratique quand on partage l\'appareil en '
                      'famille ou entre colocataires.',
                  child: _NavTile(
                    leading: const Icon(Icons.switch_account_outlined),
                    title: 'Changer de profil',
                    subtitle: Text('$count profiles available',
                        style: theme.textTheme.bodySmall),
                    onTap: () => showModalBottomSheet<void>(
                      context: context,
                      isScrollControlled: true,
                      useSafeArea: true,
                      builder: (_) => ProfilePickerScreen(
                        onPicked: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ),
                );
              }),
            ]),
            // --------------- SOURCES (admin only) ---------------
            if (isAdmin) ...[
              SettingsGroup(title: 'Playlists', children: [
                Consumer(builder: (context, ref, _) {
                  final sources = ref.watch(allSourcesProvider);
                  return InfoTooltip(
                    id: 'settings_sources',
                    title: 'Playlists',
                    body: 'Une playlist est votre connexion fournisseur — soit '
                        'une URL de playlist M3U, soit des identifiants Xtream Codes. '
                        'Les playlists fournissent vos chaînes, films et séries. '
                        'Vous pouvez ajouter plusieurs playlists et les actualiser ici.',
                    child: _NavTile(
                      leading: const Icon(Icons.playlist_play_outlined),
                      title: 'Playlists',
                      subtitle: sources.when(
                        loading: () => null,
                        error: (_, __) => null,
                        data: (list) => Text(
                          list.isEmpty
                              ? 'Aucune playlist ajoutée'
                              : '${list.length} playlist${list.length == 1 ? '' : 's'}',
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                      onTap: () => _openSourcesPage(context),
                    ),
                  );
                }),
                const RefreshAllTiles(),
              ]),
              // --------------- BACKUP (admin only) ---------------
              SettingsGroup(title: 'Données', children: [
                InfoTooltip(
                  id: 'settings_backup',
                  title: 'Sauvegarde & Restauration',
                  body: 'Exportez vos profils et playlists dans un seul '
                      'fichier .zip à conserver où vous voulez. Restaurez-le '
                      'plus tard pour changer d\'appareil ou après une réinitialisation. '
                      'Les identifiants sont inclus — gardez ce fichier en lieu sûr.',
                  child: _NavTile(
                    leading: const Icon(Icons.backup_outlined),
                    title: 'Sauvegarde & Restauration',
                    subtitle: Text(
                      'Exporter ou importer votre profil et vos playlists',
                      style: theme.textTheme.bodySmall,
                    ),
                    onTap: () => context.push('/settings/backup'),
                  ),
                ),

                // --------------- AUTO-REFRESH (admin only) ---------------
                Consumer(builder: (context, ref, _) {
                  final hours = ref.watch(refreshIntervalHoursProvider);
                  return InfoTooltip(
                    id: 'settings_auto_refresh',
                    title: 'Actualisation auto',
                    body: 'Actualise automatiquement vos playlists et le guide TV '
                        'en arrière-plan pour que chaînes et programmes restent '
                        'à jour sans intervention manuelle.',
                    child: _NavTile(
                      leading: const Icon(Icons.autorenew),
                      title: 'Actualisation auto',
                      subtitle: Text(
                        _refreshIntervalLabel(hours),
                        style: theme.textTheme.bodySmall,
                      ),
                      onTap: () => _showAutoRefreshDialog(context, ref, hours),
                    ),
                  );
                }),
                Consumer(builder: (context, ref, _) {
                  final hours = ref.watch(refreshIntervalHoursProvider);
                  if (hours <= 0) return const SizedBox.shrink();
                  final notifyEnabled =
                      ref.watch(refreshNotificationsEnabledProvider);
                  return InfoTooltip(
                    id: 'settings_refresh_notifications',
                    title: 'Notifications d\'actualisation',
                    body: 'Vous prévient quand une actualisation en arrière-plan se termine, '
                        'ou si une playlist n\'a pas pu s\'actualiser.',
                    child: _ToggleTile(
                      icon: Icons.notifications_outlined,
                      title: 'Notifications d\'actualisation',
                      value: notifyEnabled,
                      onChanged: (v) async {
                        final prefs =
                            await ref.read(appPreferencesProvider.future);
                        await setRefreshNotificationsEnabled(ref, v, prefs);
                      },
                    ),
                  );
                }),
              ]),
              // --------------- PARENTAL (admin only) ---------------
              SettingsGroup(title: 'Famille', children: [
                InfoTooltip(
                  id: 'settings_parental',
                  title: 'Contrôle parental',
                  body: 'Masquez les catégories adultes et verrouillez toute catégorie '
                      'de votre choix derrière un PIN admin. Les catégories verrouillées '
                      'restent déverrouillées jusqu\'au redémarrage de l\'app.',
                  child: _NavTile(
                    leading: const Icon(Icons.family_restroom_outlined),
                    title: 'Contrôle parental',
                    subtitle: Text(
                      'Catégories adultes et verrouillées protégées par PIN',
                      style: theme.textTheme.bodySmall,
                    ),
                    onTap: () => context.push('/settings/parental'),
                  ),
                ),
              ]),
            ],

            // --------------- PLAYBACK ---------------
            SettingsGroup(title: 'Lecture', children: [
              InfoTooltip(
                id: 'settings_continue_watching',
                title: 'Reprendre la lecture',
                body: 'Quand c\'est activé, TURBO IPTV mémorise où vous vous êtes arrêté '
                    'dans les films et séries. La prochaine fois que vous les ouvrez, '
                    "la reprise vous sera proposée.",
                child: _ToggleTile(
                  icon: Icons.play_circle_outline,
                  title: 'Reprendre la lecture',
                  value:
                      true, // TODO: wire from AppPreferences in Phase 1 completion
                  onChanged: (_) {},
                ),
              ),
              Consumer(builder: (context, ref, _) {
                final pipEnabled = ref.watch(pipEnabledProvider);
                return InfoTooltip(
                  id: 'settings_pip',
                  title: 'Image dans l\'image',
                  body: 'Quand c\'est activé, appuyer sur Accueil pendant une vidéo '
                      'la réduit en petite fenêtre flottante pour continuer '
                      'à regarder tout en utilisant d\'autres apps.',
                  child: _ToggleTile(
                    icon: Icons.picture_in_picture_alt_outlined,
                    title: 'Image dans l\'image',
                    value: pipEnabled,
                    onChanged: (v) async {
                      final prefs =
                          await ref.read(appPreferencesProvider.future);
                      await setPipEnabled(ref, v, prefs);
                    },
                  ),
                );
              }),
              Consumer(builder: (context, ref, _) {
                final notifyEnabled =
                    ref.watch(mediaNotificationEnabledProvider);
                return InfoTooltip(
                  id: 'settings_media_notification',
                  title: 'Notification média',
                  body: 'Affiche une notification « En cours » avec lecture/pause '
                      'pendant la lecture, pour contrôler depuis '
                      'le panneau de notifications ou l\'écran verrouillé.',
                  child: _ToggleTile(
                    icon: Icons.notifications_active_outlined,
                    title: 'Notification média',
                    value: notifyEnabled,
                    onChanged: (v) async {
                      final prefs =
                          await ref.read(appPreferencesProvider.future);
                      await setMediaNotificationEnabled(ref, v, prefs);
                    },
                  ),
                );
              }),
              // Android Auto video add-on (phones; installing apps is
              // an admin job).
              if (isAdmin && Platform.isAndroid && !PlatformHelper.isTVDevice)
                const CarVideoAddonTile(),
              Consumer(builder: (context, ref, _) {
                final sort = ref.watch(contentSortProvider);
                return InfoTooltip(
                  id: 'settings_sort_order',
                  title: 'Ordre de tri',
                  body: 'Contrôle l\'ordre d\'affichage des chaînes, films et séries. '
                      '« Ordre du fournisseur » suit l\'ordre envoyé par votre fournisseur IPTV. '
                      '« A–Z » trie par ordre alphabétique.',
                  child: _NavTile(
                    leading: const Icon(Icons.sort),
                    title: 'Ordre de tri',
                    subtitle: Text(
                      sort == 'az' ? 'A–Z' : 'Ordre du fournisseur',
                      style: theme.textTheme.bodySmall,
                    ),
                    onTap: () => _showSortOrderDialog(context, ref, sort),
                  ),
                );
              }),
            ]),
            // --------------- APPEARANCE ---------------
            SettingsGroup(title: 'Apparence', children: [
              Consumer(builder: (context, ref, _) {
                final accent = ref.watch(accentColorProvider);
                return InfoTooltip(
                  id: 'settings_accent_color',
                  title: 'Couleur d\'accent',
                  body: 'Change la couleur d\'accentuation dans toute l\'app — '
                      'boutons actifs, éléments sélectionnés, barres de progression et '
                      'autres indicateurs. Choisissez votre couleur préférée.',
                  child: _NavTile(
                    leading: CircleAvatar(
                      radius: 20,
                      backgroundColor: accent.withValues(alpha: 0.14),
                      child: CircleAvatar(backgroundColor: accent, radius: 10),
                    ),
                    title: 'Couleur d\'accent',
                    subtitle: Text(
                      AppTheme.accentSwatches
                          .firstWhere((s) => s.color == accent,
                              orElse: () => (label: 'Custom', color: accent))
                          .label,
                      style: theme.textTheme.bodySmall,
                    ),
                    onTap: () => _showAccentColorPicker(context, ref, accent),
                  ),
                );
              }),
              InfoTooltip(
                id: 'settings_clean_names',
                title: 'Nettoyer les noms',
                body:
                    'Nettoie les noms envoyés par votre fournisseur — supprime les étiquettes comme '
                    '« |EN| », « US| » ou « A+ - » et convertit les noms EN MAJUSCULES en '
                    'casse normale. Désactivez pour voir les noms exactement comme '
                    'votre fournisseur les envoie.',
                child: Consumer(builder: (context, ref, _) {
                  return _ToggleTile(
                    icon: Icons.auto_fix_high_outlined,
                    title: 'Nettoyer les noms',
                    value: ref.watch(cleanNamesProvider),
                    onChanged: (v) async {
                      final prefs =
                          await ref.read(appPreferencesProvider.future);
                      await setCleanNames(ref, v, prefs);
                    },
                  );
                }),
              ),
              if (isAdmin)
                InfoTooltip(
                  id: 'settings_hidden_cats',
                  title: 'Catégories masquées',
                  body: "Les catégories masquées n'apparaîtront plus dans votre liste. "
                      "Vos chaînes sont toujours là — simplement mises de côté. "
                      "Vous pouvez les réafficher ici à tout moment.",
                  child: _NavTile(
                    leading: const Icon(Icons.visibility_off_outlined),
                    title: 'Catégories masquées',
                    onTap: () => _showHiddenCategoriesPage(context),
                  ),
                ),
            ]),
            // --------------- ABOUT ---------------
            SettingsGroup(title: 'À propos', children: [
              InfoTooltip(
                id: 'settings_about',
                title: 'À propos de TURBO IPTV',
                body: 'Affiche la version actuelle et les infos de licence. '
                    'TURBO IPTV est open-source sous licence GPL-3.0 — '
                    'sans pubs, sans télémétrie, sans comptes. Pour toujours.',
                child: FutureBuilder<PackageInfo>(
                  future: PackageInfo.fromPlatform(),
                  builder: (context, snap) {
                    final version = snap.hasData
                        ? 'Version ${snap.data!.version}'
                        : 'TURBO IPTV';
                    return _NavTile(
                      leading: const Icon(Icons.info_outline),
                      title: 'À propos de TURBO IPTV',
                      subtitle: Text(version, style: theme.textTheme.bodySmall),
                      showChevron: false,
                      onTap: () => _showAboutDialog(context, snap.data),
                    );
                  },
                ),
              ),
              InfoTooltip(
                id: 'settings_check_updates',
                title: 'Vérifier les mises à jour',
                body: 'Cherche une version plus récente de TURBO IPTV sur GitHub et, si '
                    'il y en a une, affiche les changements et l\'installe. Seule '
                    'la page publique des versions est contactée — rien sur vous '
                    'ni votre appareil n\'est envoyé.',
                child: _NavTile(
                  leading: const Icon(Icons.system_update_outlined),
                  title: 'Vérifier les mises à jour',
                  subtitle: Text('Voir si une version plus récente existe',
                      style: theme.textTheme.bodySmall),
                  onTap: () => checkForUpdateManually(context),
                ),
              ),
              InfoTooltip(
                id: 'settings_auto_update',
                title: 'Vérification automatique',
                body: 'Quand c\'est activé, TURBO IPTV vérifie les nouvelles versions à chaque '
                    'démarrage et prévient les profils admin. Désactivez pour '
                    'vérifier uniquement depuis ce menu.',
                child: Consumer(builder: (context, ref, _) {
                  final prefs = ref.watch(appPreferencesProvider).valueOrNull;
                  return StatefulBuilder(
                    builder: (context, setLocal) => _ToggleTile(
                      icon: Icons.update,
                      title: 'Vérification automatique',
                      value: prefs?.autoUpdateCheck ?? true,
                      onChanged: (v) async {
                        await prefs?.setAutoUpdateCheck(v);
                        setLocal(() {});
                      },
                    ),
                  );
                }),
              ),
            ]),
            // --------------- ADVANCED (admin only, last) ---------------
            if (isAdmin)
              SettingsGroup(title: 'Avancé', children: [
                InfoTooltip(
                  id: 'settings_power_tools',
                  title: 'Outils avancés',
                  body: 'Outils pour vérifier et régler votre connexion : '
                      'adresses IP de l\'appareil et publique, type de connexion, '
                      'VPN et DNS — pratique quand un fournisseur '
                      'a du mal à vous joindre.',
                  child: _NavTile(
                    leading: const Icon(Icons.tune),
                    title: 'Outils avancés',
                    subtitle: Text('Infos réseau pour le dépannage',
                        style: theme.textTheme.bodySmall),
                    onTap: () => context.push('/settings/power-tools'),
                  ),
                ),
              ]),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  void _openSourcesPage(BuildContext context) {
    // Sources management: show a simple list with delete + refresh options.
    // Full sources page is a future enhancement; for Phase 1 we show a sheet.
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _SourcesSheet(),
    );
  }

  Future<void> _showSortOrderDialog(
      BuildContext context, WidgetRef ref, String current) async {
    final prefs = await ref.read(appPreferencesProvider.future);
    if (!context.mounted) return;
    unawaited(showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Content Sort Order'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _DialogChoice(
              label: 'Ordre du fournisseur',
              selected: current == 'provider',
              onTap: () async {
                Navigator.of(ctx).pop();
                await setContentSort(ref, 'provider', prefs);
              },
            ),
            _DialogChoice(
              label: 'A–Z',
              selected: current == 'az',
              onTap: () async {
                Navigator.of(ctx).pop();
                await setContentSort(ref, 'az', prefs);
              },
            ),
          ],
        ),
        actions: [
          TvActivatable(
            onTap: () => Navigator.of(ctx).pop(),
            builder: (onTap) =>
                TextButton(onPressed: onTap, child: const Text('Annuler')),
          ),
        ],
      ),
    ));
  }

  String _refreshIntervalLabel(int hours) {
    switch (hours) {
      case 2:
        return 'Toutes les 2 heures';
      case 6:
        return 'Toutes les 6 heures';
      case 12:
        return 'Toutes les 12 heures';
      case 24:
        return 'Toutes les 24 heures';
      default:
        return 'Désactivé';
    }
  }

  Future<void> _showAutoRefreshDialog(
      BuildContext context, WidgetRef ref, int current) async {
    final prefs = await ref.read(appPreferencesProvider.future);
    if (!context.mounted) return;
    final selected = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Actualisation auto'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [0, 2, 6, 12, 24]
              .map((hours) => _DialogChoice(
                    label: _refreshIntervalLabel(hours),
                    selected: current == hours,
                    onTap: () => Navigator.of(ctx).pop(hours),
                  ))
              .toList(),
        ),
        actions: [
          TvActivatable(
            onTap: () => Navigator.of(ctx).pop(),
            builder: (onTap) =>
                TextButton(onPressed: onTap, child: const Text('Annuler')),
          ),
        ],
      ),
    );
    if (selected == null || selected == current) return;
    if (!context.mounted) return;

    final turningOn = current <= 0 && selected > 0;
    await setRefreshIntervalHours(ref, selected, prefs);

    if (turningOn && context.mounted) {
      await _runAutoRefreshPermissionFlow(context);
    }
  }

  /// One-time rationale + permission chain, shown only when auto-refresh is
  /// turned on from Off. Declining either permission doesn't block enabling
  /// the feature — WorkManager still runs, just less reliably without the
  /// battery exemption, and silently without a visible notification if that
  /// permission is denied.
  Future<void> _runAutoRefreshPermissionFlow(BuildContext context) async {
    final wantsNotifications = await _askPermission(
      context,
      title: 'Rester informé',
      body: 'Autoriser les notifications pour que TURBO IPTV vous prévienne quand une '
          'actualisation en arrière-plan se termine ou rencontre un problème ?',
      confirmLabel: 'Autoriser',
    );
    if (wantsNotifications) {
      await requestNotificationPermission();
    }
    if (!context.mounted) return;

    final wantsBatteryExemption = await _askPermission(
      context,
      title: 'Actualisation fiable en arrière-plan',
      body: 'Certains téléphones limitent fortement les apps en arrière-plan pour économiser '
          'la batterie, ce qui peut retarder l\'actualisation. Exclure TURBO IPTV '
          'de l\'optimisation batterie rend les actualisations plus fiables.',
      confirmLabel: 'Continuer',
    );
    if (wantsBatteryExemption) {
      await requestBatteryOptimizationExemption();
    }
  }

  /// Rationale dialog shown before a system permission prompt: "Not Now" vs
  /// [confirmLabel]. Dismissing it counts as declining.
  Future<bool> _askPermission(
    BuildContext context, {
    required String title,
    required String body,
    required String confirmLabel,
  }) async {
    final accepted = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TvActivatable(
            onTap: () => Navigator.of(ctx).pop(false),
            builder: (onTap) =>
                TextButton(onPressed: onTap, child: const Text('Pas maintenant')),
          ),
          TvActivatable(
            autofocus: true,
            onTap: () => Navigator.of(ctx).pop(true),
            builder: (onTap) =>
                FilledButton(onPressed: onTap, child: Text(confirmLabel)),
          ),
        ],
      ),
    );
    return accepted ?? false;
  }

  void _showAccentColorPicker(
      BuildContext context, WidgetRef ref, Color current) {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: Text('Accent Color',
                  style: Theme.of(ctx).textTheme.titleMedium),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              child: Wrap(
                spacing: 16,
                runSpacing: 16,
                children: AppTheme.accentSwatches.asMap().entries.map((entry) {
                  final i = entry.key;
                  final swatch = entry.value;
                  final selected = swatch.color == current;
                  return TvFocusable(
                    autofocus: i == 0,
                    borderRadius: BorderRadius.circular(12),
                    onTap: () async {
                      Navigator.of(ctx).pop();
                      final prefs =
                          await ref.read(appPreferencesProvider.future);
                      await setAccentColor(ref, swatch.color, prefs);
                    },
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: swatch.color,
                            shape: BoxShape.circle,
                            border: selected
                                ? Border.all(
                                    color: Theme.of(ctx).colorScheme.onSurface,
                                    width: 3)
                                : null,
                          ),
                          child: selected
                              ? const Icon(Icons.check,
                                  color: Colors.white, size: 26)
                              : null,
                        ),
                        const SizedBox(height: 6),
                        Text(swatch.label,
                            style: Theme.of(ctx).textTheme.bodySmall),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showHiddenCategoriesPage(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) => const _HiddenCategoriesSheet(),
    );
  }

  void _showAboutDialog(BuildContext context, PackageInfo? info) {
    showAboutDialog(
      context: context,
      applicationName: 'TURBO IPTV',
      applicationVersion: info != null ? info.version : '',
      applicationLegalese:
          '© 2026 contributeurs TURBO IPTV. Licence GPL-3.0.',
      children: [
        const SizedBox(height: 16),
        const Text(
          'Un client IPTV open-source, sans pubs, multiplateforme. '
          'Sans comptes. Sans télémétrie. Sans pubs. Pour toujours.',
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Helper widgets
// ---------------------------------------------------------------------------

class _ToggleTile extends StatelessWidget {
  const _ToggleTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final bool value;
  final void Function(bool) onChanged;

  @override
  Widget build(BuildContext context) {
    return TvActivatable(
      onTap: () => onChanged(!value),
      builder: (_) => SwitchListTile(
        secondary: IconBadge(icon: icon),
        title: Text(title),
        value: value,
        onChanged: onChanged,
      ),
    );
  }
}

/// A settings row that opens something else — icon, title, optional subtitle,
/// trailing chevron — reachable by both tap and remote OK.
class _NavTile extends StatelessWidget {
  const _NavTile({
    required this.leading,
    required this.title,
    required this.onTap,
    this.subtitle,
    this.autofocus = false,
    this.showChevron = true,
  });

  final Widget leading;
  final String title;
  final Widget? subtitle;
  final VoidCallback onTap;
  final bool autofocus;
  final bool showChevron;

  @override
  Widget build(BuildContext context) {
    return TvActivatable(
      onTap: onTap,
      autofocus: autofocus,
      builder: (onTap) => ListTile(
        leading: leading is Icon
            ? IconBadge(icon: (leading as Icon).icon!)
            : leading,
        title: Text(title),
        subtitle: subtitle,
        trailing: showChevron ? const Icon(Icons.chevron_right) : null,
        onTap: onTap,
      ),
    );
  }
}

/// A radio-style dialog row: the check mark is tinted on the selected option
/// and transparent (but still occupying its slot) on the others, so the
/// labels stay aligned.
class _DialogChoice extends StatelessWidget {
  const _DialogChoice({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return TvActivatable(
      onTap: onTap,
      builder: (onTap) => SimpleDialogOption(
        onPressed: onTap,
        child: Row(children: [
          Icon(Icons.check,
              size: 18,
              color: selected
                  ? Theme.of(context).colorScheme.primary
                  : Colors.transparent),
          const SizedBox(width: 8),
          Text(label),
        ]),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Sources bottom sheet
// ---------------------------------------------------------------------------

class _SourcesSheet extends ConsumerStatefulWidget {
  const _SourcesSheet();

  @override
  ConsumerState<_SourcesSheet> createState() => _SourcesSheetState();
}

class _SourcesSheetState extends ConsumerState<_SourcesSheet> {
  final _refreshingPlaylist = <String>{};
  final _refreshingEpg = <String>{};

  /// The sheet's own messenger: a snackbar sent to the Settings page would
  /// sit behind this modal sheet, where the result can't be read.
  final _messenger = GlobalKey<ScaffoldMessengerState>();

  void _showMessage(String text) =>
      _messenger.currentState?.showSnackBar(SnackBar(content: Text(text)));

  Future<void> _refreshPlaylist(String id) async {
    if (_refreshingPlaylist.contains(id) || _refreshingEpg.contains(id)) return;
    setState(() => _refreshingPlaylist.add(id));
    try {
      final sources = await ref.read(allSourcesProvider.future);
      final source = sources.firstWhere((s) => s.id == id);
      await ref.read(sourceManagerProvider).refreshPlaylist(source);
      ref.invalidate(allSourcesProvider);
      if (mounted) {
        _showMessage('"${source.nickname}" playlist refreshed.');
      }
    } catch (e) {
      if (mounted) {
        _showMessage(
            'Playlist refresh failed: ${friendlySourceErrorMessage(e)}');
      }
    } finally {
      if (mounted) setState(() => _refreshingPlaylist.remove(id));
    }
  }

  // Closes this sheet (popped with its own context — see the lessons on
  // root-navigator sheets) and opens the editor above Settings.
  void _editSource(Source s) {
    final navigator = Navigator.of(context);
    navigator.pop();
    navigator.push(MaterialPageRoute<void>(
      builder: (_) => EditPlaylistScreen(source: s),
    ));
  }

  Future<void> _refreshEpg(String id) async {
    if (_refreshingPlaylist.contains(id) || _refreshingEpg.contains(id)) return;
    setState(() => _refreshingEpg.add(id));
    Source? source;
    try {
      final sources = await ref.read(allSourcesProvider.future);
      source = sources.firstWhere((s) => s.id == id);
      await ref.read(sourceManagerProvider).refreshEpgOnly(source);
      if (mounted) {
        _showMessage('"${source.nickname}" TV guide refreshed.');
      }
    } catch (e) {
      if (mounted) {
        _showMessage("${source?.nickname ?? 'This playlist'}'s TV guide "
            "isn't available right now. Try again later.");
      }
    } finally {
      if (mounted) setState(() => _refreshingEpg.remove(id));
    }
  }

  /// [source] null = browse every playlist together.
  Future<void> _switchSource(BuildContext context, Source? source) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Changer de playlist ?'),
        content: Text(
          source == null
              ? 'Afficher toutes les playlists ensemble ?\n\n'
                  'La liste des chaînes, les films et les séries incluront toutes les playlists.'
              : 'Passer à « ${source.nickname} » ?\n\n'
                  'La liste des chaînes, les films et les séries n\'afficheront que cette playlist.',
        ),
        actions: [
          TvActivatable(
            onTap: () => Navigator.of(ctx).pop(false),
            builder: (onTap) =>
                TextButton(onPressed: onTap, child: const Text('Annuler')),
          ),
          TvActivatable(
            autofocus: true,
            onTap: () => Navigator.of(ctx).pop(true),
            builder: (onTap) =>
                FilledButton(onPressed: onTap, child: const Text('Changer')),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      final prefs = await ref.read(appPreferencesProvider.future);
      await setActiveSource(ref, source?.id, prefs);
    }
  }

  Future<void> _confirmDelete(
    BuildContext context,
    String id,
    String nickname,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer la playlist ?'),
        content: Text('Cela supprimera « $nickname » et toutes ses chaînes, '
            'films et séries. Irréversible.'),
        actions: [
          TvActivatable(
            autofocus: true,
            onTap: () => Navigator.of(ctx).pop(false),
            builder: (onTap) =>
                TextButton(onPressed: onTap, child: const Text('Annuler')),
          ),
          TvActivatable(
            onTap: () => Navigator.of(ctx).pop(true),
            builder: (onTap) => FilledButton(
              onPressed: onTap,
              style: AppTheme.destructiveButtonStyle(ctx),
              child: const Text('Supprimer'),
            ),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(sourceManagerProvider).deleteSource(id);
      // Clear active source if it was the deleted one.
      if (ref.read(activeSourceIdProvider) == id) {
        final prefs = await ref.read(appPreferencesProvider.future);
        await setActiveSource(ref, null, prefs);
      }
      ref.invalidate(allSourcesProvider);
    }
  }

  void _showInfoPanel(BuildContext context, Source source) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _SourceInfoSheet(source: source),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sourcesAsync = ref.watch(allSourcesProvider);
    final activeSourceId = ref.watch(activeSourceIdProvider);

    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.6,
      maxChildSize: 0.9,
      builder: (context, controller) => _withMessenger(Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Playlists',
                    style: Theme.of(context).textTheme.titleLarge),
                TvActivatable(
                  // TV: something in the sheet must hold the remote, or the
                  // first key lands on an off-screen row. This is the one
                  // harmless choice (a row would switch playlists on OK).
                  autofocus: true,
                  onTap: () {
                    // Grab the router before popping — this sheet's context
                    // is torn down by the pop.
                    final router = GoRouter.of(context);
                    Navigator.of(context).pop();
                    router.push('/onboarding');
                  },
                  builder: (onTap) => FilledButton.icon(
                    icon: const Icon(Icons.add),
                    label: const Text('Ajouter une playlist'),
                    onPressed: onTap,
                  ),
                ),
              ],
            ),
          ),
          if ((sourcesAsync.valueOrNull?.length ?? 0) > 1)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Text(
                'Choisissez la playlist à parcourir, ou affichez-les toutes ensemble.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          const Divider(height: 1),
          Expanded(
            child: sourcesAsync.when(
              loading: () => const LoadingView(),
              error: (_, __) =>
                  const Center(child: Text("Impossible de charger les playlists.")),
              data: (sources) {
                if (sources.isEmpty) {
                  return const Center(child: Text('Pas encore de playlist.'));
                }
                final multiSource = sources.length > 1;
                // With several playlists, a leading "All playlists" row makes
                // the no-active-playlist state (everything merged) visible
                // and selectable.
                final allOffset = multiSource ? 1 : 0;
                return ListView.builder(
                  controller: controller,
                  itemCount: sources.length + allOffset,
                  itemBuilder: (context, index) {
                    if (index < allOffset) {
                      final allActive = activeSourceId == null;
                      return TvActivatable(
                        onTap: allActive
                            ? null
                            : () => _switchSource(context, null),
                        builder: (onTap) => ListTile(
                          leading: _PlaylistBadge(
                              icon: Icons.library_books_outlined,
                              active: allActive),
                          title: const Text('Toutes les playlists'),
                          subtitle: Text(
                            '${sources.length} playlists combinées',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          onTap: onTap,
                        ),
                      );
                    }
                    final s = sources[index - allOffset];
                    final isActive = activeSourceId == s.id ||
                        (!multiSource && activeSourceId == null);
                    final isPlaylistRefreshing =
                        _refreshingPlaylist.contains(s.id);
                    final isEpgRefreshing = _refreshingEpg.contains(s.id);
                    final isBusy = isPlaylistRefreshing || isEpgRefreshing;
                    return TvRevealOnFocus(
                      child: TvActivatable(
                        // A busy row stays focusable (doing nothing), or the
                        // remote's focus on its refresh button is lost.
                        onTap: multiSource && !isActive
                            ? (isBusy ? () {} : () => _switchSource(context, s))
                            : null,
                        builder: (onTap) => ListTile(
                          leading: _PlaylistBadge(
                              icon: Icons.playlist_play_rounded,
                              active: isActive),
                          title: Text(s.nickname),
                          subtitle: Text(
                            [
                              s.type == SourceType.xtream
                                  ? 'Xtream Codes'
                                  : LocalPlaylists.isLocal(s.m3uUrl)
                                      ? 'Playlist file'
                                      : 'M3U playlist',
                              if (isActive && multiSource) 'Browsing',
                            ].join(' · '),
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                          onTap: onTap,
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _SourceAction(
                                icon: Icons.sync_rounded,
                                tooltip: 'Actualiser la playlist',
                                busy: isBusy,
                                onTap:
                                    isBusy ? null : () => _refreshPlaylist(s.id),
                              ),
                              _SourceMenu(
                                enabled: !isBusy,
                                onEdit: () => _editSource(s),
                                onInfo: () => _showInfoPanel(context, s),
                                onRefreshGuide: () => _refreshEpg(s.id),
                                onRemove: () =>
                                    _confirmDelete(context, s.id, s.nickname),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      )),
    );
  }

  Widget _withMessenger(Widget child) => ScaffoldMessenger(
        key: _messenger,
        child: Scaffold(backgroundColor: Colors.transparent, body: child),
      );
}

/// A playlist's icon in a tinted circle; the one being browsed gets a
/// solid accent circle with a tick.
class _PlaylistBadge extends StatelessWidget {
  const _PlaylistBadge({required this.icon, required this.active});

  final IconData icon;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    if (!active) return IconBadge(icon: icon);
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      child: Icon(Icons.check_rounded,
          size: 22, color: Theme.of(context).colorScheme.onPrimary),
    );
  }
}

/// The less-used playlist actions, tucked into a ⋮ menu.
class _SourceMenu extends StatelessWidget {
  const _SourceMenu({
    required this.enabled,
    required this.onEdit,
    required this.onInfo,
    required this.onRefreshGuide,
    required this.onRemove,
  });

  final bool enabled;
  final VoidCallback onEdit;
  final VoidCallback onInfo;
  final VoidCallback onRefreshGuide;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final menuKey = GlobalKey<PopupMenuButtonState<int>>();
    final error = Theme.of(context).colorScheme.error;
    PopupMenuItem<int> item(int v, IconData icon, String label,
        [Color? color]) {
      final row = Row(children: [
        Icon(icon, size: 20, color: color),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: color)),
      ]);
      return PopupMenuItem(
        value: v,
        child: v == 3 ? TvInitialFocus(child: row) : row,
      );
    }
    return TvFocusable(
      wrapsGesture: false,
      borderRadius: BorderRadius.circular(20),
      onTap: () => enabled ? menuKey.currentState?.showButtonMenu() : null,
      child: TvMenuTheme(
        child: PopupMenuButton<int>(
          key: menuKey,
          enabled: enabled,
          tooltip: 'Plus',
          onSelected: (v) => switch (v) {
            3 => onEdit(),
            0 => onInfo(),
            1 => onRefreshGuide(),
            _ => onRemove(),
          },
          itemBuilder: (_) => [
            item(3, Icons.edit_outlined, 'Modifier la playlist'),
            item(0, Icons.info_outline, 'Infos playlist'),
            item(1, Icons.event_note_outlined, 'Actualiser le guide TV'),
            const PopupMenuDivider(),
            item(2, Icons.delete_outline, 'Supprimer', error),
          ],
        ),
      ),
    );
  }
}

/// One fixed-size slot in a playlist row's trailing action strip — an icon
/// button, or a spinner in its place while that action is running.
class _SourceAction extends StatelessWidget {
  const _SourceAction({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.busy = false,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 36,
      height: 36,
      // The same (enabled, no-op) button shows the spinner while busy:
      // swapping it for a bare spinner removed the node the remote's focus
      // was on, and focus jumped back to another playlist's row.
      child: TvActivatable(
        onTap: busy ? () {} : onTap,
        builder: (onTap) => IconButton(
          icon: busy
              ? const SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : Icon(icon, size: 20),
          tooltip: tooltip,
          onPressed: onTap,
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Source info bottom sheet (#22)
// ---------------------------------------------------------------------------

class _SourceInfoSheet extends StatefulWidget {
  const _SourceInfoSheet({required this.source});

  final Source source;

  @override
  State<_SourceInfoSheet> createState() => _SourceInfoSheetState();
}

class _SourceInfoSheetState extends State<_SourceInfoSheet> {
  bool _loading = false;
  String? _error;
  Map<String, dynamic>? _userInfo;
  Map<String, dynamic>? _serverInfo;

  @override
  void initState() {
    super.initState();
    if (widget.source.type == SourceType.xtream) _fetchInfo();
  }

  Future<void> _fetchInfo() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final client = XtreamClient.fromSource(widget.source);
    try {
      final info = await client.getServerInfo();
      if (mounted) {
        setState(() {
          _userInfo = info['user_info'] as Map<String, dynamic>?;
          _serverInfo = info['server_info'] as Map<String, dynamic>?;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Impossible de récupérer les infos du serveur.';
          _loading = false;
        });
      }
    } finally {
      client.dispose();
    }
  }

  String _formatEpoch(dynamic value) {
    if (value == null) return '—';
    final epoch = int.tryParse(value.toString());
    if (epoch == null || epoch == 0) return '—';
    final dt = DateTime.fromMillisecondsSinceEpoch(epoch * 1000);
    return formatYmd(dt);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final source = widget.source;
    final lastRefreshed = source.lastRefreshed;

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(source.nickname, style: theme.textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(
              source.type == SourceType.xtream
                  ? 'Xtream Codes'
                  : LocalPlaylists.isLocal(source.m3uUrl)
                      ? 'Playlist file'
                      : 'M3U Playlist',
              style: theme.textTheme.bodySmall,
            ),
            const Divider(height: 28),
            if (source.type == SourceType.m3u) ...[
              LocalPlaylists.isLocal(source.m3uUrl)
                  ? const _InfoRow('Source', 'Fichier enregistré sur cet appareil')
                  : _InfoRow('URL', redactUrl(source.m3uUrl ?? '—')),
              if (source.epgUrl != null) _InfoRow('EPG URL', redactUrl(source.epgUrl!)),
              _InfoRow(
                'Last refreshed',
                lastRefreshed != null ? formatYmd(lastRefreshed) : 'Never',
              ),
            ] else if (_loading) ...[
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: CircularProgressIndicator(),
                ),
              ),
            ] else if (_error != null) ...[
              Text(_error!, style: TextStyle(color: theme.colorScheme.error)),
            ] else ...[
              _InfoRow('Status', '${_userInfo?['status'] ?? '—'}'),
              _InfoRow('Expires', _formatEpoch(_userInfo?['exp_date'])),
              _InfoRow(
                  'Active connections', '${_userInfo?['active_cons'] ?? '—'}'),
              _InfoRow(
                  'Max connections', '${_userInfo?['max_connections'] ?? '—'}'),
              _InfoRow('Trial', _userInfo?['is_trial'] == '1' ? 'Oui' : 'Non'),
              const Divider(height: 24),
              _InfoRow('Server',
                  '${_serverInfo?['url'] ?? source.xtreamHost ?? '—'}'),
              _InfoRow('Timezone', '${_serverInfo?['timezone'] ?? '—'}'),
            ],
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow(this.label, this.value);

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: theme.textTheme.bodyMedium,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Hidden categories sheet
// ---------------------------------------------------------------------------

class _HiddenCategoriesSheet extends ConsumerWidget {
  const _HiddenCategoriesSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(activeProfileProvider).valueOrNull;
    final hidden = profile?.hiddenCategories ?? [];

    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.5,
      maxChildSize: 0.9,
      builder: (context, controller) => Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text('Hidden Categories',
                style: Theme.of(context).textTheme.titleLarge),
          ),
          const Divider(height: 1),
          Expanded(
            child: hidden.isEmpty
                ? const Center(child: Text('No categories are hidden.'))
                : ListView.builder(
                    controller: controller,
                    itemCount: hidden.length,
                    itemBuilder: (context, i) => ListTile(
                      title: Text(hidden[i]),
                      trailing: TvActivatable(
                        autofocus: i == 0,
                        onTap: profile == null
                            ? null
                            : () async {
                                await ref
                                    .read(profileServiceProvider)
                                    .unhideCategory(profile.id, hidden[i]);
                                ref.invalidate(activeProfileProvider);
                              },
                        builder: (onTap) => TextButton(
                          onPressed: onTap,
                          child: const Text('Show'),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
