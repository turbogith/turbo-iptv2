import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:open_iptv/core/models/source.dart';
import 'package:open_iptv/core/providers/theme_providers.dart';
import 'package:open_iptv/core/services/profile_service.dart';
import 'package:open_iptv/core/services/source_manager.dart';
import 'package:open_iptv/core/storage/local_playlists.dart';
import 'package:open_iptv/core/storage/preferences.dart';
import 'package:open_iptv/features/settings/backup_screen.dart';
import 'package:open_iptv/shared/theme/app_theme.dart';
import 'package:open_iptv/shared/utils/friendly_error.dart';
import 'package:open_iptv/shared/widgets/device_file_picker.dart';
import 'package:open_iptv/shared/widgets/pin_field.dart';
import 'package:open_iptv/shared/widgets/tv_focusable.dart';
import 'package:open_iptv/ui/platform_helper.dart';

String _firstName(String name) =>
    name.trim().isNotEmpty ? name.trim().split(' ').first : 'vous';

/// A lighter tint of [color], used for the wizard's gradient accents.
Color _lighten(Color color, [double amount = 0.3]) =>
    Color.lerp(color, Colors.white, amount)!;

// ---------------------------------------------------------------------------
// SetupWizardScreen
// ---------------------------------------------------------------------------

/// First-run setup (profile → PIN → playlist), or — with [addPlaylistOnly]
/// — just the playlist steps, for adding another playlist to an existing
/// install (Settings → Playlists → Add Playlist, or after every playlist has
/// been deleted).
class SetupWizardScreen extends ConsumerStatefulWidget {
  const SetupWizardScreen({super.key, this.addPlaylistOnly = false});

  final bool addPlaylistOnly;

  @override
  ConsumerState<SetupWizardScreen> createState() => _SetupWizardScreenState();
}

class _SetupWizardScreenState extends ConsumerState<SetupWizardScreen>
    with TickerProviderStateMixin {
  // Playlist-only mode starts straight at the playlist-type page; the
  // profile pages before it are never shown.
  static const _playlistTypePage = 3;
  late final _pageController = PageController(initialPage: _firstPage);

  int get _firstPage => widget.addPlaylistOnly ? _playlistTypePage : 0;

  // The page being shown — Back steps through these before leaving.
  late int _page = _firstPage;

  // Profile state
  final _nameCtrl = TextEditingController();
  final _nameFocusNode = FocusNode();
  // Each explicitly requestFocus()'d from _goToPage at the moment the
  // wizard actually navigates to that page — see _nameFocusNode's original
  // comment and TvFocusable.focusNode's doc for why plain `autofocus: true`
  // doesn't work reliably on this PageView (every page is built up front,
  // so autofocus fires far too early and loses the initial-focus race to
  // whichever page happened to build first).
  final _pin1FocusNode = FocusNode();
  final _xtreamCardFocusNode = FocusNode();
  final _nicknameFocusNode = FocusNode();
  String _avatarEmoji = '🧑';
  Color _accentColor = AppTheme.defaultAccent;
  String _pin = '';

  // Source state
  SourceType _playlistType = SourceType.xtream;
  // "Playlist File": an M3U picked from the device instead of a URL.
  bool _fromFile = false;
  String? _pickedFileName;
  String? _pickedFileContent;
  final _nicknameCtrl = TextEditingController();
  final _xtreamHostCtrl = TextEditingController();
  final _xtreamUserCtrl = TextEditingController();
  final _xtreamPassCtrl = TextEditingController();
  bool _passVisible = false;
  final _m3uUrlCtrl = TextEditingController();
  final _epgUrlCtrl = TextEditingController();

  // Loading / all-set state
  bool _isLoading = false;
  bool _restoring = false;
  String? _errorMessage;
  String _progressMessage = 'Connexion…';

  // All-set animations
  late final AnimationController _checkCtrl;
  late final Animation<double> _checkScale;
  late final AnimationController _sparkleCtrl;
  late final Animation<double> _sparkleAngle;

  @override
  void initState() {
    super.initState();
    _checkCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _checkScale = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _checkCtrl, curve: Curves.elasticOut),
    );
    _sparkleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat();
    _sparkleAngle = Tween(begin: 0.0, end: 2 * pi).animate(_sparkleCtrl);

    if (widget.addPlaylistOnly) {
      // Existing install — keep the user's accent, and give the D-pad its
      // starting point on the first page shown.
      _accentColor = ref.read(accentColorProvider);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _xtreamCardFocusNode.requestFocus();
      });
    }

    // Autofocus on a TextField at page-transition time (rather than the
    // widget's own `autofocus: true`) is notoriously unreliable at getting
    // Android's soft keyboard to actually show — the IME often only shows
    // for a focus change it can tie to a genuine user gesture. Nudging it
    // explicitly here (also re-armed in the focus listener below) is the
    // standard workaround.
    _nameFocusNode.onKeyEvent = (node, event) {
      if (event is! KeyDownEvent) return KeyEventResult.ignored;
      // TextField swallows arrow keys for cursor movement, which — with
      // nothing to move to in a single-line field — otherwise traps D-pad
      // focus inside it with no way out (reported directly by a user
      // testing on a real Android TV remote).
      final key = event.logicalKey;
      final ctx = node.context;
      if (ctx == null) return KeyEventResult.ignored;
      if (key == LogicalKeyboardKey.arrowDown) {
        FocusScope.of(ctx).nextFocus();
        return KeyEventResult.handled;
      }
      if (key == LogicalKeyboardKey.arrowUp) {
        FocusScope.of(ctx).previousFocus();
        return KeyEventResult.handled;
      }
      return KeyEventResult.ignored;
    };
    _nameFocusNode.addListener(() {
      if (_nameFocusNode.hasFocus) {
        SystemChannels.textInput.invokeMethod('TextInput.show');
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _checkCtrl.dispose();
    _sparkleCtrl.dispose();
    _nameCtrl.dispose();
    _nameFocusNode.dispose();
    _pin1FocusNode.dispose();
    _xtreamCardFocusNode.dispose();
    _nicknameFocusNode.dispose();
    _nicknameCtrl.dispose();
    _xtreamHostCtrl.dispose();
    _xtreamUserCtrl.dispose();
    _xtreamPassCtrl.dispose();
    _m3uUrlCtrl.dispose();
    _epgUrlCtrl.dispose();
    super.dispose();
  }

  void _goToPage(int page, {bool requestFocus = true}) {
    setState(() => _page = page);
    _pageController.animateToPage(
      page,
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeInOutCubic,
    );
    // PageView keeps every page built at once, so each page's own controls
    // exist (and could otherwise steal focus) well before that page is
    // actually shown — only request focus once we're actually navigating
    // to it, on whichever control should be the D-pad starting point there.
    final focusNode = switch (page) {
      1 => _nameFocusNode,
      2 => _pin1FocusNode,
      3 => _xtreamCardFocusNode,
      4 => _nicknameFocusNode,
      _ => null,
    };
    if (requestFocus && focusNode != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) focusNode.requestFocus();
      });
    }
  }

  Future<void> _pickPlaylistFile() async {
    FocusScope.of(context).unfocus();
    PickedDeviceFile? file;
    try {
      // Any type in the system picker: Android has no reliable MIME type for
      // .m3u/.m3u8, so a filter hides real playlists. Contents are checked.
      file = await pickDeviceFile(context,
          title: 'Choisir un fichier playlist',
          extensions: const ['.m3u', '.m3u8', '.txt']);
    } catch (_) {
      if (mounted) {
        setState(() => _errorMessage =
            "Impossible d'ouvrir le sélecteur de fichiers sur cet appareil.");
      }
      return;
    }
    final picked = file;
    if (picked == null || !mounted) return;
    try {
      final content = LocalPlaylists.decode(picked.bytes);
      setState(() {
        _pickedFileName = picked.name;
        _pickedFileContent = content;
        _errorMessage = null;
      });
    } on LocalPlaylistException catch (e) {
      setState(() {
        _pickedFileName = null;
        _pickedFileContent = null;
        _errorMessage = friendlySourceErrorMessage(e);
      });
    }
  }

  Future<void> _submitSource() async {
    FocusScope.of(context).unfocus();
    if (_fromFile && _pickedFileContent == null) {
      setState(() => _errorMessage = 'Choisissez d\'abord un fichier playlist.');
      return;
    }
    // Say what's missing rather than trying to connect with blanks and
    // failing with a vague error.
    final missing = _playlistType == SourceType.xtream
        ? [
            if (_xtreamHostCtrl.text.trim().isEmpty) 'adresse serveur',
            if (_xtreamUserCtrl.text.trim().isEmpty) 'nom d\'utilisateur',
            if (_xtreamPassCtrl.text.trim().isEmpty) 'mot de passe',
          ]
        : [if (!_fromFile && _m3uUrlCtrl.text.trim().isEmpty) 'URL M3U'];
    if (missing.isNotEmpty) {
      final list = missing.length == 1
          ? missing.first
          : '${missing.sublist(0, missing.length - 1).join(', ')} et '
              '${missing.last}';
      setState(() => _errorMessage = 'Il manque : $list (demandez à votre fournisseur).');
      return;
    }
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _progressMessage = 'Connexion…';
    });
    _goToPage(5);

    try {
      final manager = ref.read(sourceManagerProvider);
      var nickname = _nicknameCtrl.text.trim();
      if (nickname.isEmpty && _fromFile) {
        nickname = _pickedFileName!.replaceAll(RegExp(r'\.m3u8?$',
            caseSensitive: false), '');
      }
      final epgUrl = _epgUrlCtrl.text.trim().isEmpty
          ? null
          : _epgUrlCtrl.text.trim();

      void onProgress(String msg) {
        if (mounted) setState(() => _progressMessage = msg);
      }

      // Add the playlist first — it's the step most likely to fail (bad
      // credentials, bad URL, network issues). Only create the profile once
      // it succeeds, so a failed attempt leaves nothing behind to retry into.
      final isM3u = _playlistType == SourceType.m3u;
      await manager.addSource(
        nickname: nickname,
        type: _playlistType,
        m3uUrl: isM3u && !_fromFile ? _m3uUrlCtrl.text.trim() : null,
        m3uFileContent: isM3u && _fromFile ? _pickedFileContent : null,
        xtreamHost: isM3u ? null : _xtreamHostCtrl.text.trim(),
        xtreamUsername: isM3u ? null : _xtreamUserCtrl.text.trim(),
        xtreamPassword: isM3u ? null : _xtreamPassCtrl.text.trim(),
        epgUrl: epgUrl,
        onProgress: onProgress,
      );

      if (!mounted) return;

      if (!widget.addPlaylistOnly) {
        final prefs = await ref.read(appPreferencesProvider.future);
        final db = ref.read(appDatabaseProvider);
        final profileSvc = ProfileService(db: db, prefs: prefs);
        await profileSvc.createProfile(
          name: _nameCtrl.text.trim(),
          avatarEmoji: _avatarEmoji,
          pin: _pin.isEmpty ? null : _pin,
          isAdmin: true,
        );

        // Persist and apply the chosen accent colour immediately.
        await prefs.setAccentColor(AppTheme.hexFromAccent(_accentColor));
        ref.read(accentColorProvider.notifier).state = _accentColor;
      }

      if (!mounted) return;
      ref.invalidate(allSourcesProvider);

      _goToPage(6);
      unawaited(_checkCtrl.forward());
      await Future.delayed(const Duration(seconds: 3));
      if (mounted) _finish();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _errorMessage = friendlySourceErrorMessage(e);
      });
      // On touch devices, refocusing the nickname field would pop the
      // keyboard straight back up over the error; TV still needs a D-pad
      // starting point.
      _goToPage(4, requestFocus: PlatformHelper.isTV(context));
    }
  }

  /// Welcome page → "Restore from a backup": brings back profiles, playlists
  /// and settings, then downloads each playlist's channels (a backup holds
  /// playlist logins, not their contents) on the loading page.
  Future<void> _restoreFromBackup() async {
    final summary = await restoreBackupFromFile(context, ref);
    if (summary == null || !mounted) return;

    final db = ref.read(appDatabaseProvider);
    final prefs = await ref.read(appPreferencesProvider.future);
    final profiles = await db.getAllProfiles();
    final sources = await db.getAllSources();
    if (profiles.isEmpty || sources.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              "That backup doesn't include a profile and a playlist, so "
              "there's nothing to restore yet. Tap Get Started instead.")));
      return;
    }
    // One profile: use it. Several: start on an admin one (the person
    // restoring holds the whole backup anyway); the picker is available
    // from Settings afterwards.
    final active = profiles.length == 1
        ? profiles.first
        : profiles.firstWhere((p) => p.isAdmin, orElse: () => profiles.first);
    await prefs.setActiveProfileId(active.id);
    ref.invalidate(activeProfileProvider);
    ref.read(accentColorProvider.notifier).state =
        AppTheme.accentFromHex(prefs.accentColor);
    if (!mounted) return;

    setState(() {
      _isLoading = true;
      _restoring = true;
      // Show the restored accent, not the wizard's default.
      _accentColor = AppTheme.accentFromHex(prefs.accentColor);
      _progressMessage = 'Connexion…';
    });
    _goToPage(5);
    final manager = ref.read(sourceManagerProvider);
    for (final (i, source) in sources.indexed) {
      final label = sources.length > 1
          ? '${source.nickname} (${i + 1} of ${sources.length})'
          : source.nickname;
      try {
        await manager.refreshSource(source, onProgress: (msg) {
          if (mounted) setState(() => _progressMessage = '$label — $msg');
        });
      } catch (e) {
        // One unreachable playlist mustn't block the rest; it can be
        // refreshed from Settings later.
        debugPrint('[OTV-restore] refresh failed for ${source.nickname}: $e');
      }
    }
    if (!mounted) return;
    ref.invalidate(allSourcesProvider);
    context.go('/live');
  }

  /// Back to wherever the wizard was opened from (Settings), or into the
  /// app when it's the root route (first run, or no playlists left).
  void _finish() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/live');
    }
  }

  @override
  Widget build(BuildContext context) {
    final addOnly = widget.addPlaylistOnly;
    // Step dots count only the pages this mode actually shows.
    final stepOffset = addOnly ? _playlistTypePage - 1 : 0;
    final totalSteps = addOnly ? 2 : 4;
    // Back (remote, gesture, system button) goes one step back, like the
    // on-screen arrow; only from the first page does it leave the wizard.
    // Nothing happens while a playlist loads (page 5).
    return PopScope(
      canPop: _page == _firstPage,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop || _page >= 5 || _page <= _firstPage) return;
        _goToPage(_page - 1);
      },
      child: Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      resizeToAvoidBottomInset: true,
      body: PageView(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          // Placeholders keep page indices stable in playlist-only mode
          // without building (and autofocusing) the profile pages.
          if (addOnly) ...[
            const SizedBox.shrink(),
            const SizedBox.shrink(),
            const SizedBox.shrink(),
          ] else ...[
          _WelcomePage(
            onStart: () => _goToPage(1),
            onRestore: _restoreFromBackup,
          ),
          _NamePage(
            nameCtrl: _nameCtrl,
            nameFocusNode: _nameFocusNode,
            selectedAvatar: _avatarEmoji,
            onAvatarSelected: (e) => setState(() => _avatarEmoji = e),
            selectedColor: _accentColor,
            onColorSelected: (c) => setState(() => _accentColor = c),
            onContinue: () {
              if (_nameCtrl.text.trim().isEmpty) return;
              _goToPage(2);
            },
          ),
          _PinPage(
            accentColor: _accentColor,
            firstDigitFocusNode: _pin1FocusNode,
            onSkip: () {
              setState(() => _pin = '');
              _goToPage(3);
            },
            onPinSet: (pin) {
              setState(() => _pin = pin);
              _goToPage(3);
            },
          ),
          ],
          _PlaylistTypePage(
            accentColor: _accentColor,
            firstCardFocusNode: _xtreamCardFocusNode,
            step: 2 - stepOffset,
            totalSteps: totalSteps,
            addingPlaylist: addOnly,
            onBack: addOnly && context.canPop() ? () => context.pop() : null,
            onSelected: (type) {
              setState(() {
                _playlistType = type;
                _fromFile = false;
                _errorMessage = null;
              });
              _goToPage(4);
            },
            onFileSelected: () {
              setState(() {
                _playlistType = SourceType.m3u;
                _fromFile = true;
                _errorMessage = null;
              });
              _goToPage(4);
            },
          ),
          _CredentialsPage(
            accentColor: _accentColor,
            playlistType: _playlistType,
            fromFile: _fromFile,
            pickedFileName: _pickedFileName,
            onPickFile: _pickPlaylistFile,
            nicknameCtrl: _nicknameCtrl,
            nicknameFocusNode: _nicknameFocusNode,
            xtreamHostCtrl: _xtreamHostCtrl,
            xtreamUserCtrl: _xtreamUserCtrl,
            xtreamPassCtrl: _xtreamPassCtrl,
            passVisible: _passVisible,
            onTogglePass: () => setState(() => _passVisible = !_passVisible),
            m3uUrlCtrl: _m3uUrlCtrl,
            epgUrlCtrl: _epgUrlCtrl,
            errorMessage: _errorMessage,
            step: 3 - stepOffset,
            totalSteps: totalSteps,
            onBack: () => _goToPage(3),
            onSubmit: _isLoading ? null : _submitSource,
          ),
          _LoadingPage(
            message: _progressMessage,
            accentColor: _accentColor,
            title: _restoring
                ? 'Restauration de vos playlists…'
                : 'Configuration de votre playlist…',
          ),
          _AllSetPage(
            headline: addOnly
                ? 'Playlist ajoutée !'
                : "C'est prêt, ${_firstName(_nameCtrl.text)} !",
            accentColor: _accentColor,
            checkScale: _checkScale,
            sparkleAngle: _sparkleAngle,
          ),
        ],
      ),
    ),
    );
  }
}

// ---------------------------------------------------------------------------
// Page 0 — Welcome
// ---------------------------------------------------------------------------

class _WelcomePage extends StatefulWidget {
  const _WelcomePage({required this.onStart, required this.onRestore});
  final VoidCallback onStart;
  // Fresh install from an existing backup (reinstall, new Fire Stick) —
  // skips creating a profile and playlist by hand.
  final VoidCallback onRestore;

  @override
  State<_WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<_WelcomePage>
    with TickerProviderStateMixin {
  late final AnimationController _fadeCtrl;
  late final AnimationController _glowCtrl;
  late final Animation<double> _fade;
  late final Animation<double> _slide;
  late final Animation<double> _glowPulse;
  late final Animation<double> _btnScale;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _glowPulse = Tween(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
    _fade = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _fadeCtrl,
        curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
      ),
    );
    _slide = Tween(begin: 30.0, end: 0.0).animate(
      CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic),
    );
    _btnScale = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _fadeCtrl,
        curve: const Interval(0.5, 1.0, curve: Curves.elasticOut),
      ),
    );

    _fadeCtrl.forward();
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _WizardBackground(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            children: [
              const Spacer(flex: 3),
              AnimatedBuilder(
                animation: Listenable.merge([_fadeCtrl, _glowCtrl]),
                builder: (_, child) => Opacity(
                  opacity: _fade.value,
                  child: SizedBox(
                    width: 160,
                    height: 160,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 160,
                          height: 160,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                Color.fromRGBO(91, 79, 255, _glowPulse.value * 0.3),
                                Color.fromRGBO(58, 46, 204, _glowPulse.value * 0.12),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: 110,
                          height: 110,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                Color.fromRGBO(123, 111, 255, _glowPulse.value * 0.2),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                        child!,
                      ],
                    ),
                  ),
                ),
                child: Image.asset(
                  'assets/images/logo_mark.png',
                  width: 150,
                  height: 150,
                ),
              ),
              const SizedBox(height: 48),
              AnimatedBuilder(
                animation: _fadeCtrl,
                builder: (_, __) => Transform.translate(
                  offset: Offset(0, _slide.value),
                  child: Opacity(
                    opacity: _fade.value,
                    child: Column(
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [Colors.white, Color(0xFFC0B8FF)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ).createShader(bounds),
                          child: const Text(
                            'Bienvenue sur\nTURBO IPTV',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 34,
                              fontWeight: FontWeight.w800,
                              height: 1.25,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          "Configurons tout.\nCela ne prend qu'une minute.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppTheme.mutedTextColor,
                            fontSize: 16,
                            height: 1.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const Spacer(flex: 2),
              AnimatedBuilder(
                animation: _fadeCtrl,
                builder: (_, child) =>
                    Transform.scale(scale: _btnScale.value, child: child),
                child: _GradientButton(
                  label: 'Commencer',
                  icon: Icons.arrow_forward,
                  accentColor: AppTheme.accentSwatches.first.color,
                  onTap: widget.onStart,
                ),
              ),
              const SizedBox(height: 12),
              FadeTransition(
                opacity: _fade,
                child: TvActivatable(
                  onTap: widget.onRestore,
                  builder: (onTap) => TextButton.icon(
                    onPressed: onTap,
                    icon: const Icon(Icons.settings_backup_restore,
                        color: AppTheme.mutedTextColor),
                    label: const Text(
                      'Restaurer depuis une sauvegarde',
                      style: TextStyle(
                          color: AppTheme.mutedTextColor, fontSize: 15),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 28),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Page 1 — Name + Avatar
// ---------------------------------------------------------------------------

class _NamePage extends StatelessWidget {
  const _NamePage({
    required this.nameCtrl,
    required this.nameFocusNode,
    required this.selectedAvatar,
    required this.onAvatarSelected,
    required this.selectedColor,
    required this.onColorSelected,
    required this.onContinue,
  });

  final TextEditingController nameCtrl;
  final FocusNode nameFocusNode;
  final String selectedAvatar;
  final ValueChanged<String> onAvatarSelected;
  final Color selectedColor;
  final ValueChanged<Color> onColorSelected;
  final VoidCallback onContinue;

  static const _avatars = [
    '👨', '👩', '🧒', '👦', '👧', '🧑', '👴', '👵',
    '🎭', '🌟', '🎮', '🎬', '📺', '🎵', '🏠', '⚽',
    '🎸', '🐱', '🐶', '🦄',
  ];

  @override
  Widget build(BuildContext context) {
    final isTV = PlatformHelper.isTV(context);
    // A modest bump, not a multiplier applied blindly — Android TV renders
    // at a much higher density than a phone (this hardware reports 1920x1080
    // physical but only ~960x540 *logical* px), so the actual usable height
    // on TV is often SHORTER than a phone's, not taller. The scrollable
    // wrapper below is the real safety net; this is just breathing room.
    double v(double base) => isTV ? base * 1.15 : base;

    return _WizardBackground(
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(
              horizontal: 28, vertical: isTV ? 16 : 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
              SizedBox(height: v(24)),
              _StepIndicator(current: 0, total: 4, accentColor: selectedColor),
              SizedBox(height: v(36)),
              const Text(
                "Comment vous appelez-vous ?",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                ),
              ),
              SizedBox(height: v(8)),
              const Text(
                'Tout reste sur votre appareil.\nTURBO IPTV ne collecte aucune donnée personnelle.',
                style: TextStyle(color: AppTheme.mutedTextColor, fontSize: 14, height: 1.5),
              ),
              SizedBox(height: v(32)),
              TvTextFieldGate(
                focusNode: nameFocusNode,
                borderRadius: const BorderRadius.all(Radius.circular(14)),
                builder: (context, fieldNode) => TextField(
                controller: nameCtrl,
                focusNode: fieldNode,
                textCapitalization: TextCapitalization.words,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => onContinue(),
                style: const TextStyle(color: Colors.white, fontSize: 18),
                decoration: InputDecoration(
                  hintText: 'Votre nom',
                  hintStyle: const TextStyle(color: AppTheme.mutedTextColor),
                  filled: true,
                  fillColor: AppTheme.surfaceVariantColor,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: AppTheme.outlineColor),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: AppTheme.outlineColor),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: selectedColor, width: 2),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 18),
                ),
              ),
              ),
              SizedBox(height: v(32)),
              const Text(
                'Choisissez un avatar',
                style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
              ),
              SizedBox(height: v(12)),
              SizedBox(
                height: 62,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _avatars.length,
                  itemBuilder: (context, i) {
                    final emoji = _avatars[i];
                    final selected = emoji == selectedAvatar;
                    return TvFocusable(
                      borderRadius: BorderRadius.circular(14),
                      ensureVisibleOnFocus: true,
                      onTap: () => onAvatarSelected(emoji),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        margin: const EdgeInsets.only(right: 10),
                        width: 54,
                        height: 54,
                        decoration: BoxDecoration(
                          color: selected
                              ? selectedColor.withValues(alpha: 0.2)
                              : AppTheme.surfaceVariantColor,
                          border: Border.all(
                            color: selected ? selectedColor : AppTheme.outlineColor,
                            width: selected ? 2 : 1,
                          ),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Center(
                          child: Text(emoji,
                              style: const TextStyle(fontSize: 26)),
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: v(28)),
              const Text(
                'Couleur d\'accent',
                style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    fontWeight: FontWeight.w600),
              ),
              SizedBox(height: v(12)),
              Row(
                children: AppTheme.accentSwatches.map((s) {
                  final sel = s.color == selectedColor;
                  return Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: TvFocusable(
                      borderRadius: BorderRadius.circular(19),
                      onTap: () => onColorSelected(s.color),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: s.color,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: sel ? Colors.white : Colors.transparent,
                            width: 3,
                          ),
                          boxShadow: sel
                              ? [
                                  BoxShadow(
                                    color: s.color.withValues(alpha: 0.6),
                                    blurRadius: 12,
                                    spreadRadius: 2,
                                  ),
                                ]
                              : null,
                        ),
                        child: sel
                            ? const Icon(Icons.check,
                                color: Colors.white, size: 18)
                            : null,
                      ),
                    ),
                  );
                }).toList(),
              ),
                    ],
                  ),
                ),
              ),
              // Continue is a sibling of the scrollable content above, not a
              // child inside it — always visible and reachable regardless of
              // how tall the content above ends up (scrolls instead of
              // pushing this off-screen, unlike the old Spacer-based layout).
              SizedBox(height: v(16)),
              _GradientButton(
                label: 'Continuer',
                icon: Icons.arrow_forward,
                accentColor: selectedColor,
                onTap: onContinue,
              ),
              SizedBox(height: v(20)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Page 2 — PIN (optional)
// ---------------------------------------------------------------------------

class _PinPage extends StatefulWidget {
  const _PinPage({
    required this.accentColor,
    required this.onSkip,
    required this.onPinSet,
    required this.firstDigitFocusNode,
  });
  final Color accentColor;
  final VoidCallback onSkip;
  final ValueChanged<String> onPinSet;
  final FocusNode firstDigitFocusNode;

  @override
  State<_PinPage> createState() => _PinPageState();
}

class _PinPageState extends State<_PinPage> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  bool get _valid => _controller.text.length >= kPinMinLength;

  void _submit() {
    if (!_valid) return;
    // Close the keyboard before the next page slides in.
    FocusManager.instance.primaryFocus?.unfocus();
    widget.onPinSet(_controller.text);
  }

  @override
  Widget build(BuildContext context) {
    final isTV = PlatformHelper.isTV(context);
    // See _NamePage — a modest bump only, TV's usable height can be
    // shorter than a phone's, not taller. The Expanded/SingleChildScrollView
    // below is the real safety net against overflow.
    double v(double base) => isTV ? base * 1.15 : base;

    return _WizardBackground(
      child: SafeArea(
        child: Padding(
          padding:
              EdgeInsets.symmetric(horizontal: 28, vertical: isTV ? 16 : 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: v(24)),
                      _StepIndicator(
                          current: 1, total: 4, accentColor: widget.accentColor),
                      SizedBox(height: v(36)),
                      const Text(
                        'Sécurisez votre compte',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.w800),
                      ),
                      SizedBox(height: v(8)),
                      const Text(
                        'Définissez un code PIN de 4 à 8 chiffres pour protéger ce compte admin.\nVous pouvez passer et l\'ajouter plus tard dans les réglages.',
                        style: TextStyle(
                            color: AppTheme.mutedTextColor, fontSize: 14, height: 1.5),
                      ),
                      SizedBox(height: v(40)),
                      Center(
                        child: ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 320),
                          child: Theme(
                            data: Theme.of(context).copyWith(
                              colorScheme: Theme.of(context)
                                  .colorScheme
                                  .copyWith(primary: widget.accentColor),
                            ),
                            // System number keyboard, opened when the page
                            // is shown (the wizard focuses this node).
                            child: PinField(
                              controller: _controller,
                              focusNode: widget.firstDigitFocusNode,
                              autofocus: false,
                              onChanged: (_) => setState(() {}),
                              onSubmitted: (_) => _submit(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: v(16)),
              _GradientButton(
                label: 'Définir le PIN',
                icon: Icons.lock,
                accentColor: widget.accentColor,
                onTap: _valid ? _submit : null,
              ),
              SizedBox(height: v(12)),
              Center(
                child: TextButton(
                  onPressed: widget.onSkip,
                  child: const Text(
                    'Passer pour l\'instant',
                    style: TextStyle(color: AppTheme.mutedTextColor, fontSize: 15),
                  ),
                ),
              ),
              SizedBox(height: v(16)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Page 3 — Playlist type selector
// ---------------------------------------------------------------------------

class _PlaylistTypePage extends StatelessWidget {
  const _PlaylistTypePage({
    required this.accentColor,
    required this.onSelected,
    required this.firstCardFocusNode,
    required this.step,
    required this.totalSteps,
    required this.onFileSelected,
    this.addingPlaylist = false,
    this.onBack,
  });
  final Color accentColor;
  final ValueChanged<SourceType> onSelected;
  final VoidCallback onFileSelected;
  final FocusNode firstCardFocusNode;
  final int step;
  final int totalSteps;
  final bool addingPlaylist;
  // Set when there's somewhere to go back to (playlist-only mode opened
  // from Settings) — the first-run flow has no way back from here.
  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) {
    final isTV = PlatformHelper.isTV(context);
    // See _NamePage — a modest bump only; the SingleChildScrollView below
    // is what actually protects against overflow on TV's shorter viewport.
    double v(double base) => isTV ? base * 1.15 : base;

    return _WizardBackground(
      child: SafeArea(
        child: Padding(
          padding:
              EdgeInsets.symmetric(horizontal: 28, vertical: isTV ? 16 : 0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: v(24)),
                // With a back arrow, the header is pulled left 12px to sit
                // exactly where the credentials page's header does (that
                // page has 12px less side padding), so it doesn't jump
                // between steps.
                Transform.translate(
                  offset: Offset(onBack != null ? -12 : 0, 0),
                  child: Row(
                    children: [
                      if (onBack != null) ...[
                        IconButton(
                          icon: const Icon(Icons.arrow_back,
                              color: Colors.white70),
                          tooltip: 'Retour',
                          onPressed: onBack,
                        ),
                        const SizedBox(width: 4),
                      ],
                      _StepIndicator(
                          current: step,
                          total: totalSteps,
                          accentColor: accentColor),
                    ],
                  ),
                ),
                SizedBox(height: v(36)),
                Text(
                  addingPlaylist
                      ? 'Quel type de playlist\najoutez-vous ?'
                      : 'Quel type de playlist\navez-vous ?',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                  ),
                ),
                SizedBox(height: v(8)),
                const Text(
                  "Un doute ? Demandez à votre fournisseur IPTV, il saura !",
                  style: TextStyle(color: AppTheme.mutedTextColor, fontSize: 14),
                ),
                SizedBox(height: v(40)),
                _PlaylistTypeCard(
                  icon: Icons.dns_rounded,
                  title: 'Xtream Codes',
                  description:
                      'Connexion avec adresse serveur, identifiant et mot de passe.',
                  accentColor: accentColor,
                  onTap: () => onSelected(SourceType.xtream),
                  focusNode: firstCardFocusNode,
                ),
                SizedBox(height: v(16)),
                _PlaylistTypeCard(
                  icon: Icons.link_rounded,
                  title: 'M3U Playlist',
                  description:
                      'Charger depuis une URL de playlist directe (en .m3u ou .m3u8).',
                  accentColor: accentColor,
                  onTap: () => onSelected(SourceType.m3u),
                ),
                SizedBox(height: v(16)),
                _PlaylistTypeCard(
                  icon: Icons.upload_file_rounded,
                  title: 'Playlist File',
                  description:
                      'Choisir un fichier .m3u enregistré sur cet appareil.',
                  accentColor: accentColor,
                  onTap: onFileSelected,
                ),
                SizedBox(height: v(16)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _PlaylistTypeCard extends StatefulWidget {
  const _PlaylistTypeCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.accentColor,
    required this.onTap,
    this.focusNode,
  });

  final IconData icon;
  final String title;
  final String description;
  final Color accentColor;
  final VoidCallback onTap;
  // See TvFocusable.focusNode's doc — plain autofocus isn't reliable here
  // since this card lives inside a wizard PageView page that's built up
  // front, long before it's actually shown.
  final FocusNode? focusNode;

  @override
  State<_PlaylistTypeCard> createState() => _PlaylistTypeCardState();
}

class _PlaylistTypeCardState extends State<_PlaylistTypeCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pressCtrl;

  @override
  void initState() {
    super.initState();
    _pressCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 120),
      lowerBound: 0.95,
      upperBound: 1.0,
      value: 1.0,
    );
  }

  @override
  void dispose() {
    _pressCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Only scrolls when a card is cut off (centring it pushed the page's
    // back arrow off the top of the screen).
    return TvRevealOnFocus(
      child: TvFocusable(
      wrapsGesture: false,
      focusNode: widget.focusNode,
      borderRadius: BorderRadius.circular(20),
      onTap: widget.onTap,
      child: GestureDetector(
      onTapDown: (_) => _pressCtrl.reverse(),
      onTapUp: (_) {
        _pressCtrl.forward();
        widget.onTap();
      },
      onTapCancel: () => _pressCtrl.forward(),
      child: AnimatedBuilder(
        animation: _pressCtrl,
        builder: (_, child) =>
            Transform.scale(scale: _pressCtrl.value, child: child),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.surfaceColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppTheme.outlineColor),
          ),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: widget.accentColor.withValues(alpha: 0.16),
                  shape: BoxShape.circle,
                ),
                child: Icon(widget.icon, color: widget.accentColor, size: 28),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.description,
                      style: const TextStyle(
                        color: AppTheme.mutedTextColor,
                        fontSize: 13,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              const Icon(Icons.chevron_right,
                  color: AppTheme.mutedTextColor, size: 20),
            ],
          ),
        ),
      ),
      ),
    ),
    );
  }
}

// ---------------------------------------------------------------------------
// Page 4 — Credentials form
// ---------------------------------------------------------------------------

class _CredentialsPage extends StatelessWidget {
  const _CredentialsPage({
    required this.accentColor,
    required this.playlistType,
    required this.fromFile,
    required this.pickedFileName,
    required this.onPickFile,
    required this.nicknameCtrl,
    required this.xtreamHostCtrl,
    required this.xtreamUserCtrl,
    required this.xtreamPassCtrl,
    required this.passVisible,
    required this.onTogglePass,
    required this.m3uUrlCtrl,
    required this.epgUrlCtrl,
    required this.errorMessage,
    required this.step,
    required this.totalSteps,
    required this.onBack,
    required this.onSubmit,
    required this.nicknameFocusNode,
  });

  final Color accentColor;
  final SourceType playlistType;
  final bool fromFile;
  final String? pickedFileName;
  final VoidCallback onPickFile;
  final TextEditingController nicknameCtrl;
  final FocusNode nicknameFocusNode;
  final TextEditingController xtreamHostCtrl;
  final TextEditingController xtreamUserCtrl;
  final TextEditingController xtreamPassCtrl;
  final bool passVisible;
  final VoidCallback onTogglePass;
  final TextEditingController m3uUrlCtrl;
  final TextEditingController epgUrlCtrl;
  final String? errorMessage;
  final int step;
  final int totalSteps;
  final VoidCallback onBack;
  final VoidCallback? onSubmit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isXtream = playlistType == SourceType.xtream;
    return _WizardBackground(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 24, 28, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back,
                            color: Colors.white70),
                        tooltip: 'Retour',
                        onPressed: onBack,
                      ),
                      const SizedBox(width: 4),
                      _StepIndicator(
                          current: step,
                          total: totalSteps,
                          accentColor: accentColor),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isXtream
                              ? 'Xtream Credentials'
                              : fromFile
                                  ? 'Playlist File'
                                  : 'M3U Playlist',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          isXtream
                              ? 'Enter the login details from your provider.'
                              : fromFile
                                  ? 'Choose the playlist file saved on this device.'
                                  : 'Paste the playlist link your provider gave you.',
                          style:
                              const TextStyle(color: AppTheme.mutedTextColor, fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _TopFade(
                child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(28, 20, 28, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _WizardField(
                      label: fromFile ? 'Nickname (optional)' : 'Nom de la playlist',
                      ctrl: nicknameCtrl,
                      hint: fromFile
                          ? 'Uses the file name if left blank'
                          : 'e.g. Home Server',
                      accentColor: accentColor,
                      focusNode: nicknameFocusNode,
                    ),
                    const SizedBox(height: 16),
                    if (isXtream) ...[
                      _WizardField(
                        label: 'Server Address',
                        ctrl: xtreamHostCtrl,
                        hint: 'http://your-provider.com:8080',
                        type: TextInputType.url,
                        accentColor: accentColor,
                      ),
                      const SizedBox(height: 16),
                      _WizardField(
                        label: 'Nom d\'utilisateur',
                        ctrl: xtreamUserCtrl,
                        hint: 'your_username',
                        accentColor: accentColor,
                      ),
                      const SizedBox(height: 16),
                      _WizardField(
                        label: 'Mot de passe',
                        ctrl: xtreamPassCtrl,
                        hint: 'your_password',
                        obscure: !passVisible,
                        accentColor: accentColor,
                        suffix: IconButton(
                          icon: Icon(
                            passVisible
                                ? Icons.visibility_off
                                : Icons.visibility,
                            color: AppTheme.mutedTextColor,
                          ),
                          tooltip: passVisible ? 'Hide password' : 'Show password',
                          onPressed: onTogglePass,
                        ),
                      ),
                    ] else if (fromFile) ...[
                      _FilePickerField(
                        fileName: pickedFileName,
                        accentColor: accentColor,
                        onTap: onPickFile,
                      ),
                      const SizedBox(height: 16),
                      _WizardField(
                        label: 'TV Guide URL (optional)',
                        ctrl: epgUrlCtrl,
                        hint: 'https://example.com/epg.xml',
                        type: TextInputType.url,
                        accentColor: accentColor,
                      ),
                    ] else ...[
                      _WizardField(
                        label: 'URL M3U',
                        ctrl: m3uUrlCtrl,
                        hint: 'https://example.com/playlist.m3u',
                        type: TextInputType.url,
                        accentColor: accentColor,
                      ),
                      const SizedBox(height: 16),
                      _WizardField(
                        label: 'TV Guide URL (optional)',
                        ctrl: epgUrlCtrl,
                        hint: 'https://example.com/epg.xml',
                        type: TextInputType.url,
                        accentColor: accentColor,
                      ),
                    ],
                    if (errorMessage != null) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.error.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: theme.colorScheme.error.withValues(alpha: 0.4)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.error_outline,
                                color: theme.colorScheme.error, size: 18),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                errorMessage!,
                                style: TextStyle(
                                    color: theme.colorScheme.error, fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 28),
                    _GradientButton(
                      label: 'Load My Playlist',
                      icon: Icons.download,
                      accentColor: accentColor,
                      onTap: onSubmit,
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// The "choose a file" control on the Playlist File page, styled like a
/// wizard text field; shows the picked file's name once chosen.
class _FilePickerField extends StatelessWidget {
  const _FilePickerField({
    required this.fileName,
    required this.accentColor,
    required this.onTap,
  });

  final String? fileName;
  final Color accentColor;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final picked = fileName != null;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Playlist file',
          style: TextStyle(
              color: Colors.white70,
              fontSize: 13,
              fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 6),
        TvFocusable(
          wrapsGesture: false,
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Material(
            color: AppTheme.surfaceVariantColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(
                color: picked ? accentColor : AppTheme.outlineColor,
                width: picked ? 1.5 : 1,
              ),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: onTap,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: [
                    Icon(
                      picked
                          ? Icons.description_rounded
                          : Icons.folder_open_rounded,
                      color: picked ? accentColor : AppTheme.mutedTextColor,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        fileName ?? 'Choose a file…',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: picked
                              ? Colors.white
                              : AppTheme.mutedTextColor,
                          fontSize: 15,
                        ),
                      ),
                    ),
                    Text(
                      picked ? 'Change' : 'Browse',
                      style: TextStyle(
                        color: accentColor,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _WizardField extends StatelessWidget {
  const _WizardField({
    required this.label,
    required this.ctrl,
    required this.hint,
    required this.accentColor,
    this.type,
    this.obscure = false,
    this.suffix,
    this.focusNode,
  });

  final String label;
  final TextEditingController ctrl;
  final String hint;
  final Color accentColor;
  final TextInputType? type;
  final bool obscure;
  final Widget? suffix;
  // See TvFocusable.focusNode's doc — plain autofocus isn't reliable on a
  // wizard page that's built up front, long before it's actually shown.
  final FocusNode? focusNode;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
              color: Colors.white70,
              fontSize: 13,
              fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 6),
        TvTextFieldGate(
          focusNode: focusNode,
          builder: (context, fieldNode) => TextField(
          controller: ctrl,
          focusNode: fieldNode,
          keyboardType: type,
          obscureText: obscure,
          autocorrect: false,
          textInputAction: TextInputAction.next,
          style: const TextStyle(color: Colors.white, fontSize: 15),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: AppTheme.mutedTextColor),
            filled: true,
            fillColor: AppTheme.surfaceVariantColor,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppTheme.outlineColor),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppTheme.outlineColor),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: accentColor, width: 2),
            ),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            suffixIcon: suffix,
          ),
        ),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// Page 5 — Loading
// ---------------------------------------------------------------------------

class _LoadingPage extends StatefulWidget {
  const _LoadingPage({
    required this.message,
    required this.accentColor,
    this.title = 'Configuration de votre playlist…',
  });
  final String message;
  final Color accentColor;
  final String title;

  @override
  State<_LoadingPage> createState() => _LoadingPageState();
}

class _LoadingPageState extends State<_LoadingPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulse = Tween(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _WizardBackground(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 90,
                height: 90,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _pulse,
                      builder: (_, __) => Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: RadialGradient(
                            colors: [
                              widget.accentColor
                                  .withValues(alpha: _pulse.value * 0.25),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                    CircularProgressIndicator(
                      color: widget.accentColor,
                      strokeWidth: 3,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              Text(
                widget.title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Opacity(
                  opacity: 0.5 + _pulse.value * 0.5,
                  child: Text(
                    widget.message,
                    style: const TextStyle(color: AppTheme.mutedTextColor, fontSize: 14),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Page 6 — All set!
// ---------------------------------------------------------------------------

class _AllSetPage extends StatelessWidget {
  const _AllSetPage({
    required this.headline,
    required this.accentColor,
    required this.checkScale,
    required this.sparkleAngle,
  });

  final String headline;
  final Color accentColor;
  final Animation<double> checkScale;
  final Animation<double> sparkleAngle;

  @override
  Widget build(BuildContext context) {
    return _WizardBackground(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                width: 200,
                height: 200,
                child: AnimatedBuilder(
                  animation: Listenable.merge([checkScale, sparkleAngle]),
                  builder: (_, __) {
                    return Stack(
                      alignment: Alignment.center,
                      children: [
                        // Orbiting sparkle dots
                        ...List.generate(12, (i) {
                          final angle =
                              sparkleAngle.value + (i * 2 * pi / 12);
                          final radius = i % 2 == 0 ? 80.0 : 72.0;
                          final dx = cos(angle) * radius;
                          final dy = sin(angle) * radius;
                          final size = i % 3 == 0
                              ? 7.0
                              : i % 3 == 1
                                  ? 5.0
                                  : 4.0;
                          return Transform.translate(
                            offset: Offset(dx, dy),
                            child: Container(
                              width: size,
                              height: size,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: i % 3 == 0
                                    ? accentColor
                                    : i % 3 == 1
                                        ? _lighten(accentColor)
                                        : Colors.white
                                            .withValues(alpha: 0.5),
                              ),
                            ),
                          );
                        }),
                        // Outer glow
                        Container(
                          width: 130,
                          height: 130,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: RadialGradient(
                              colors: [
                                accentColor.withValues(alpha: 0.3),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                        // Checkmark
                        Transform.scale(
                          scale: checkScale.value,
                          child: Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                colors: [accentColor, _lighten(accentColor)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: accentColor.withValues(alpha: 0.5),
                                  blurRadius: 30,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 54,
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 44),
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Colors.white, Color(0xFFC0B8FF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ).createShader(bounds),
                child: Text(
                  headline,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Your playlist is ready.\nEnjoy the show.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppTheme.mutedTextColor, fontSize: 16, height: 1.6),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

class _WizardBackground extends StatelessWidget {
  const _WizardBackground({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    // This wizard's pages are all designed at phone width (fixed 28px side
    // padding, buttons/cards that stretch to fill whatever width they're
    // given) — full-bleed on a TV screen stretches everything into an
    // oversized, "mooshed"-looking layout. Capping and centering the width
    // here, in the one shared background wrapper every page uses, fixes all
    // of them at once without touching each page's own layout.
    //
    // Height is deliberately NOT force-fit here — Android TV renders at a
    // much higher density than a phone (this hardware: 1920x1080 physical
    // but only ~960x540 *logical* px, since TV UI is drawn bigger for
    // 10-foot viewing), so the actual usable height on TV can be SHORTER
    // than a phone's, not taller. Each page handles its own vertical
    // overflow (scrolling the middle, pinning the action button) rather
    // than this wrapper guessing at available height.
    Widget wrap(Widget page) {
      if (!PlatformHelper.isTV(context)) return page;
      return Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 640),
          child: page,
        ),
      );
    }

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppTheme.backgroundColor, AppTheme.surfaceColor],
        ),
      ),
      child: wrap(child),
    );
  }
}

class _StepIndicator extends StatelessWidget {
  const _StepIndicator({
    required this.current,
    required this.total,
    required this.accentColor,
  });
  final int current;
  final int total;
  final Color accentColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(total, (i) {
        final active = i == current;
        final done = i < current;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.only(right: 6),
          width: active ? 28 : 8,
          height: 8,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: active
                ? accentColor
                : done
                    ? _lighten(accentColor).withValues(alpha: 0.6)
                    : AppTheme.outlineColor,
          ),
        );
      }),
    );
  }
}

class _GradientButton extends StatelessWidget {
  const _GradientButton({
    required this.label,
    required this.icon,
    required this.accentColor,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color accentColor;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return TvFocusable(
      autofocus: enabled,
      onTap: onTap ?? () {},
      borderRadius: BorderRadius.circular(14),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 200),
        opacity: enabled ? 1.0 : 0.45,
        child: Container(
          height: 56,
          decoration: BoxDecoration(
            gradient: enabled
                ? LinearGradient(
                    colors: [accentColor, _lighten(accentColor)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  )
                : null,
            color: enabled ? null : AppTheme.surfaceVariantColor,
            borderRadius: BorderRadius.circular(14),
            boxShadow: enabled
                ? [
                    BoxShadow(
                      color: accentColor.withValues(alpha: 0.4),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 10),
              Icon(icon, color: Colors.white, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

/// Fades content out as it scrolls under the page header, instead of a
/// hard cut (the TV keyboard scrolls the form under it). Only the top
/// [height] fades, which the form's own top padding covers at rest.
class _TopFade extends StatelessWidget {
  const _TopFade({required this.child});

  static const height = 20.0;

  final Widget child;

  @override
  Widget build(BuildContext context) => ShaderMask(
        blendMode: BlendMode.dstIn,
        shaderCallback: (rect) => LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: const [Colors.transparent, Colors.black],
          stops: [0, height / rect.height],
        ).createShader(rect),
        child: child,
      );
}
