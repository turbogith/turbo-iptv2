import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:open_iptv/app.dart';
import 'package:open_iptv/core/services/auto_refresh_service.dart';
import 'package:open_iptv/core/services/car_library.dart';
import 'package:open_iptv/core/services/epg_service.dart';
import 'package:open_iptv/core/services/now_playing_service.dart';
import 'package:open_iptv/core/services/playback_service.dart';
import 'package:open_iptv/core/services/profile_service.dart';
import 'package:open_iptv/core/services/source_manager.dart';
import 'package:open_iptv/core/storage/preferences.dart';
import 'package:open_iptv/ui/platform_helper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Must resolve before the orientation lock below — a TV has no rotation
  // concept and no portrait mode at all, so requesting one here causes
  // Android to letterbox the whole app into a small portrait compat box.
  await PlatformHelper.initTvDetection();
  if (!PlatformHelper.isTVDevice) {
    unawaited(
        SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]));
  }
  await initAutoRefresh();

  // Built here (rather than implicitly by ProviderScope) so the same
  // PlaybackService singleton can be handed to audio_service before runApp —
  // the Now Playing notification must mirror the exact Player instance the
  // rest of the app plays through, not a separate one.
  final container = ProviderContainer();
  await initNowPlayingService(container.read(playbackServiceProvider));
  // Android Auto's browse tree reads the same data, profile and playlist
  // as the app (the car may start the app without its screen — see
  // EngineChannels.kt). Phones and tablets only: TVs never connect to a
  // car, so the car library isn't set up there at all.
  debugPrint('[OTV-auto] car library '
      '${PlatformHelper.isTVDevice ? 'off (TV)' : 'on'}');
  if (!PlatformHelper.isTVDevice) {
    nowPlayingHandler
      ..library = CarLibrary(
        db: container.read(appDatabaseProvider),
        loadPrefs: () => container.read(appPreferencesProvider.future),
        loadProfile: () => container.read(activeProfileProvider.future),
        fetchEpisodes: (seriesId, sourceId) => container
            .read(sourceManagerProvider)
            .fetchEpisodesForSeries(seriesId, sourceId),
        nowOn: (channelId) async => (await container
                .read(epgServiceProvider)
                .getCurrentProgramme(channelId))
            ?.title,
      )
      ..currentProfileId =
          () async => (await container.read(activeProfileProvider.future))?.id;
  }

  runApp(
    UncontrolledProviderScope(
      container: container,
      child: const OpenIPTVApp(),
    ),
  );
}
