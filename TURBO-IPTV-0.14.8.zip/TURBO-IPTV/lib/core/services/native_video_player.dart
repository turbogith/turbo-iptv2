import 'dart:async';

import 'package:flutter/services.dart';

/// Playback state snapshot from the native ExoPlayer engine.
class NativeVideoPlayerState {
  const NativeVideoPlayerState({
    required this.position,
    required this.duration,
    required this.playing,
    this.playWhenReady = false,
    this.suppressed = false,
    required this.buffering,
    required this.completed,
    required this.videoWidth,
    required this.videoHeight,
    this.pixelRatio = 1.0,
  });

  final Duration position;
  final Duration duration;
  /// Frames are actually moving (false while paused *or* stalled).
  final bool playing;

  /// The player is meant to be playing — false only when paused. Together
  /// with [playing] this tells a freeze from a pause.
  final bool playWhenReady;

  /// Held back by the system although [playWhenReady] (e.g. a phone call
  /// took audio focus). Not a stall.
  final bool suppressed;
  final bool buffering;
  final bool completed;
  // First real decoded frame's size — 0 until one has actually rendered,
  // the same "definitely not just blocky decoder warmup" signal
  // media_kit's videoParams.w>0 gave the buffering overlay.
  final int videoWidth;
  final int videoHeight;
  // Pixel width/height ratio; 1.0 except for anamorphic content.
  final double pixelRatio;

  bool get hasVideo => videoWidth > 0;

  /// Display aspect ratio of the content, or null until the first frame.
  double? get aspectRatio => videoWidth > 0 && videoHeight > 0
      ? videoWidth * pixelRatio / videoHeight
      : null;
}

/// A playback failure reported by the native engine.
class NativePlaybackError {
  const NativePlaybackError({required this.code, this.httpStatus});

  // ExoPlayer PlaybackException error-code name, e.g. ERROR_CODE_IO_BAD_HTTP_STATUS.
  final String code;
  // Set when the server answered with an HTTP error status.
  final int? httpStatus;

  /// The server says this stream doesn't exist or isn't allowed — retrying
  /// won't help.
  bool get isPermanent =>
      httpStatus == 401 ||
      httpStatus == 403 ||
      httpStatus == 404 ||
      httpStatus == 410;
}

/// One audio or subtitle/CC track, as reported by ExoPlayer's track model.
class NativeVideoTrack {
  const NativeVideoTrack({
    required this.id,
    required this.type,
    required this.label,
    required this.language,
    required this.selected,
    this.mimeType,
    this.channel = -1,
  });

  factory NativeVideoTrack.fromMap(Map<Object?, Object?> map) {
    return NativeVideoTrack(
      id: map['id'] as String,
      type: map['type'] as String,
      label: map['label'] as String,
      language: map['language'] as String?,
      selected: map['selected'] as bool,
      mimeType: map['mimeType'] as String?,
      channel: map['channel'] as int? ?? -1,
    );
  }

  final String id;
  // 'audio' or 'text' (subtitle/CC).
  final String type;
  final String label;
  final String? language;
  final bool selected;
  // e.g. 'application/cea-608'; null if unknown.
  final String? mimeType;
  // CEA-608/708 caption channel/service number, or -1.
  final int channel;
}

/// Dart wrapper around the native ExoPlayer-based video engine
/// (android/app/.../NativeVideoPlayer.kt), replacing media_kit/mpv.
///
/// One instance == one native texture/ExoPlayer pair. Create multiple
/// instances for concurrent playback (e.g. the TV guide's mini preview).
class NativeVideoPlayer {
  static const _control = MethodChannel('openiptv/video_player');

  int? _textureId;
  StreamSubscription<dynamic>? _eventSub;
  final _stateController =
      StreamController<NativeVideoPlayerState>.broadcast();
  final _cueController = StreamController<String>.broadcast();
  final _errorController = StreamController<NativePlaybackError>.broadcast();
  final _tracksController = StreamController<List<NativeVideoTrack>>.broadcast();

  /// The Flutter `Texture` widget's `textureId` once [create] resolves.
  int get textureId => _textureId!;
  bool get isCreated => _textureId != null;

  Stream<NativeVideoPlayerState> get stateStream => _stateController.stream;
  // Current subtitle/CC cue text — empty string means "nothing showing".
  Stream<String> get cueStream => _cueController.stream;
  Stream<NativePlaybackError> get errorStream => _errorController.stream;
  Stream<List<NativeVideoTrack>> get tracksStream => _tracksController.stream;

  /// [audioFocus]: this player is the app's media audio (holds focus, so
  /// Android Auto routes it to the car). False for silent previews.
  Future<int> create({bool audioFocus = true}) async {
    final id = await _control
        .invokeMethod<int>('create', {'audioFocus': audioFocus});
    _textureId = id;
    final events = EventChannel('openiptv/video_player_events/$id');
    _eventSub = events.receiveBroadcastStream().listen((event) {
      final map = Map<Object?, Object?>.from(event as Map);
      switch (map['type']) {
        case 'cues':
          _cueController.add(map['text'] as String? ?? '');
        case 'tracks':
          final list = (map['tracks'] as List)
              .map((t) => NativeVideoTrack.fromMap(
                  Map<Object?, Object?>.from(t as Map)))
              .toList();
          _tracksController.add(list);
        case 'error':
          _errorController.add(NativePlaybackError(
            code: map['code'] as String? ?? 'unknown',
            httpStatus: map['httpStatus'] as int?,
          ));
        default:
          _stateController.add(NativeVideoPlayerState(
            position: Duration(milliseconds: map['position'] as int),
            duration: Duration(milliseconds: map['duration'] as int),
            playing: map['playing'] as bool,
            playWhenReady: map['playWhenReady'] as bool? ?? false,
            suppressed: map['suppressed'] as bool? ?? false,
            buffering: map['buffering'] as bool,
            completed: map['completed'] as bool? ?? false,
            videoWidth: map['videoWidth'] as int? ?? 0,
            videoHeight: map['videoHeight'] as int? ?? 0,
            pixelRatio: (map['pixelRatio'] as num?)?.toDouble() ?? 1.0,
          ));
      }
    });
    return id!;
  }

  Future<List<NativeVideoTrack>> getTracks() async {
    final result =
        await _control.invokeMethod<List<Object?>>('getTracks', {'id': _textureId});
    return (result ?? [])
        .map((t) => NativeVideoTrack.fromMap(Map<Object?, Object?>.from(t as Map)))
        .toList();
  }

  Future<void> selectTrack(String trackId) => _control.invokeMethod(
      'selectTrack', {'id': _textureId, 'trackId': trackId});

  Future<void> clearTextTrack() =>
      _control.invokeMethod('clearTextTrack', {'id': _textureId});

  /// [bufferPreset]: a [BufferPreset] id; the native player rebuilds its
  /// buffer settings when it changes.
  Future<void> open(String url,
      {String? streamTypeHint,
      Duration? startPosition,
      String bufferPreset = 'fast',
      bool carScreen = false}) {
    return _control.invokeMethod('open', {
      'id': _textureId,
      'url': url,
      'streamTypeHint': streamTypeHint,
      'startPositionMs': startPosition?.inMilliseconds ?? 0,
      'bufferPreset': bufferPreset,
      'carScreen': carScreen,
    });
  }

  Future<void> play() => _control.invokeMethod('play', {'id': _textureId});

  /// Whether this is the player you hear: full volume and media audio
  /// focus, or muted without focus (multi-view's other tiles).
  Future<void> setAudible(bool on) =>
      _control.invokeMethod('setAudible', {'id': _textureId, 'on': on});
  Future<void> setSpeed(double speed) => _control
      .invokeMethod('setSpeed', {'id': _textureId, 'speed': speed});
  Future<void> pause() => _control.invokeMethod('pause', {'id': _textureId});
  Future<void> stop() => _control.invokeMethod('stop', {'id': _textureId});

  // Returns the resulting position immediately (ExoPlayer updates its
  // position synchronously, unlike mpv's async position reporting).
  Future<Duration> seekTo(Duration position) async {
    final ms = await _control.invokeMethod<int>('seekTo', {
      'id': _textureId,
      'positionMs': position.inMilliseconds,
    });
    return Duration(milliseconds: ms ?? position.inMilliseconds);
  }

  Future<void> dispose() async {
    await _eventSub?.cancel();
    if (_textureId != null) {
      await _control.invokeMethod('dispose', {'id': _textureId});
    }
    await _stateController.close();
    await _cueController.close();
    await _errorController.close();
    await _tracksController.close();
  }
}
