# TURBO IPTV - Compiler l'APK avec GitHub (sans rien installer)

Le fichier `.github/workflows/build-apk.yml` (deja inclus) compile
l'APK automatiquement sur les serveurs de GitHub. Duree : ~15 a 25 min
la premiere fois (telechargement du SDK + sources OpenVPN), puis plus
rapide ensuite (cache).

## Etape 1 - Dezipper l'archive

Dezippez `TURBO-IPTV-0.14.8.zip` : vous obtenez un dossier `TURBO-IPTV/`
avec tout le code source.

## Etape 2 - Creer le depot GitHub

1. Creez un compte sur https://github.com (gratuit).
2. Cliquez `+` (en haut a droite) -> `New repository`.
3. Nom : `turbo-iptv`, `Private` (prive = gratuit), **ne cochez pas**
   "Add a README" -> `Create repository`.

## Etape 3 - Envoyer le code (methode simple : GitHub Desktop)

1. Installez GitHub Desktop : https://desktop.github.com.
2. Connectez-vous, puis `File -> Clone repository...` -> choisissez
   `turbo-iptv` -> `Clone`.
3. Copiez **le contenu** du dossier `TURBO-IPTV/` (pas le dossier
   lui-meme) dans le dossier clone (celui que GitHub Desktop a cree).
4. Dans GitHub Desktop : resume "TURBO IPTV" -> `Commit to main` ->
   `Push origin`.

Variante terminal (si git est installe) :
```bash
cd TURBO-IPTV
git init -b main
git add .
git commit -m "TURBO IPTV"
git remote add origin https://github.com/VOTRE-PSEUDO/turbo-iptv.git
git push -u origin main
```

## Etape 4 - Lancer la compilation

1. Sur la page du depot : onglet `Actions`.
2. A gauche : `Compiler TURBO IPTV (APK)` -> le build demarre tout seul
   apres le push. Sinon : `Run workflow`.
3. Attendez le ✅ vert (cliquez dessus pour voir la progression).

## Etape 5 - Telecharger et installer l'APK

1. En bas de la page du build reussi : `Artifacts` ->
   telechargez `TURBO-IPTV-APK` (contient `app-release.apk`).
2. Envoyez l'APK sur votre telephone/tablette Android (USB, Drive...).
3. Ouvrez-le : autorisez "sources inconnues" si demande.
4. Si l'installation echoue avec un conflit de signature, desinstallez
   d'abord l'OpenIPTV d'origine (meme identifiant d'application).

## Recompiler apres une modification

Modifiez les fichiers (sur GitHub directement ou en local + push) :
un nouveau build demarre automatiquement, avec un nouvel APK.

Limites gratuites : 2000 minutes Actions/mois en prive (un build = ~20
min) et artefacts gardes 90 jours. Largement suffisant.
